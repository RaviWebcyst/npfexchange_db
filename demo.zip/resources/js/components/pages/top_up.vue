<template>
    <div>
        <Header />
    <div class="container-fluid mt-5 px-4 pt-5">
        <div class="row col-lg-4 mx-auto">
            <div class="d-flex justify-content-between">
                <h3 style="color:white !important;">Top Up</h3>
                <router-link :to="{ name: 'future_trade' }"   class="nav-link text-white mt-3"  > Trade Now </router-link>

            </div>
            <div class="card ">
                            <form class="my-4"  >
                                <div class="mb-4">
                                    <label for="address" class="form-label ">Amount</label>
                                    <input type="text" class="form-control" id="amount" v-model="amount" required  placeholder="Enter Amount" >
                                </div>
                                <button type="button" class="btn flex-fill btn-light-success fs-5 text-uppercase " @click="topUp" :disabled="top_up"  >
                                    Submit
                                   <div class="spinner-grow spinner-grow-sm text-success" role="status" v-if="top_up"  ></div>
                               </button>
                            </form>
                    </div>
                </div>
            </div>
    </div>
</template>

<script>
 import pagination from 'vue-pagination-2';
export default {
  name: 'top_up',
  components:{
        pagination
     },
  data(){
    return {
        apiUrl:process.env.mix_api_url,
        amount : "",
        error:false,
        success:false,
        balance:0,
         message:"",
        top_up : false,

    }
  },
  methods: {

    topUp(){
                this.top_up = true;
                axios.post(this.apiUrl+"api/top_up",{
                    token:localStorage.token,
                    amount:this.amount,


                }).then(res=>{
                    console.log(res);
                    this.amount = '',
                    this.top_up = false;
                    this.$toaster.success(res.data.message);

                }).catch(err=>{
                    console.log(err);
                    this.top_up = false;
                    this.$toaster.error(err.response.data.message);
                });

        },

    }


}
</script>
