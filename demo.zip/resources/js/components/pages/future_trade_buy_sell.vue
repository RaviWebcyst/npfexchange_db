<template>



    <div class="col-md-3 mt-2">
        <div class="card mb-3" style="max-height: 535px; overflow: scroll;">
            <div class="card-header py-3 d-flex justify-content-between bg-transparent border-bottom-0 pt-5">
                <h6 class="mb-0 fw-bold text-light">Future</h6>
            </div>
            <div class="card-body">
                <!-- leverage option start  -->
                <div class="mb-3 mt-1">
                    <button type="button" class="bg-black border-0 text-white px-4 py-1" data-bs-toggle="modal"
                        data-bs-target="#leverageModal" @click="getLeverages" :class="{ 'd-none': !auth }">
                        {{ final_leverage }}x</button>
                    <button type="button" class="bg-black border-0 text-white px-4 py-1" data-bs-toggle="modal"
                        data-bs-target="#crossModal" @click="getLeverages" :class="{ 'd-none': !auth }"> {{
                        final_margin}}</button>
                    <margin_mode :coin="coin" :selectedButton="selectedButton" @callParentFunction="getLeverages">
                    </margin_mode>

                    <!-- leverage modal start  -->
                    <div class="modal fade " id="leverageModal" data-bs-backdrop="static" data-bs-keyboard="false"
                        tabindex="-1" aria-labelledby="leverageModalLabel" aria-hidden="true">
                        <div class="modal-dialog centered " style="margin-top:150px">
                            <div class="modal-content bg-dark">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="transfer_usdt">Adjust Leverage
                                    </h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                        aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <label for="">Leverage</label>
                                    <div class="input-group mb-3">
                                        <button class="border-0 px-4 bg-black" type="button" @click="subLev">-</button>
                                        <input type="text" id="leverage" class="form-control text-center bg-black"
                                            :value="leverage + 'x'" readonly>
                                        <button class="border-0 px-4 bg-black" type="button" @click="addLev">+</button>
                                    </div>

                                    <div class="input-group mb-3 px-3">
                                        <div class="mb-2 d-flex justify-content-between align-items-center w-100">
                                            <span class="text-muted">1x</span>
                                            <span class="text-muted px-2">25x</span>
                                            <span class="text-muted px-1">50x</span>
                                            <span class="text-muted px-1">75x</span>
                                            <span class="text-muted">100x</span>
                                            <span class="text-muted">125x</span>
                                        </div>
                                        <input type="range" class="custom-range" id="rangeInput" min="1" max="125"
                                            step="1" v-model="leverage" />

                                    </div>
                                    <ul style="list-style-type: disc;">
                                        <li> <small> Maximum position at current leverage: 20,000,000 USDT </small></li>
                                        <li> <small> Please note that leverage changing will also apply for open
                                                positions and open orders.</small></li>
                                    </ul>
                                    <ul class="mt-2 warning-list">
                                        <li class="text-danger"><small> Selecting higher leverage such as [10x]
                                                increases your liquidation risk. Always manage your risk levels. See our
                                                help article for more information. </small></li>
                                    </ul>
                                    <div class="d-flex justify-content-center">
                                        <button class="btn butn rounded text-dark mb-4 mt-3 " type="button"
                                            :disabled="leveraging" @click="setLeverage">Confirm
                                            <span class="spinner-grow spinner-grow-sm pl-2" role="status"
                                                aria-hidden="true" v-if="leveraging"></span>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <ul class="nav nav-tabs tab-body-header   border-0 nav-fill" role="tablist">

                    <li class="nav-item" role="presentation"><a class="nav-link future-link active" data-bs-toggle="tab"
                            href="#Market" role="tab" aria-selected="false" tabindex="-1"
                            @click="EnableInput('market')">Market</a></li>
                    <li class="nav-item" role="presentation"><a class="nav-link future-link " data-bs-toggle="tab"
                            href="#Market" role="tab" aria-selected="true" @click="EnableInput('limit')">Limit</a></li>
                    <!-- <li class="nav-item" role="presentation"><a class="nav-link" data-bs-toggle="tab" href="#Stoplimit" role="tab" aria-selected="false" tabindex="-1">Stop Limit</a></li> -->
                </ul>
                <div class="tab-content">

                    <!-- Trade card start -->

                    <div class="tab-pane fade show active" id="Market" role="tabpanel">

                        <div class="row g-3 tab-content">

                            <div class="col-lg-12 tab-pane fade show active  "
                                :class="{ ' py-2': disable_input, 'py-1': !disable_input }" id="open" role="tabpanel">

                                <div class="d-flex align-items-center justify-content-between my-3">
                                    <span class="small text-muted">Avbl</span>
                                    <span class="">{{ usd }} USDT</span>
                                </div>
                                <form class="pb-4">
                                    <div class="input-group mb-3" :class="{ 'd-none': disable_input }">
                                        <span class="input-group-text custom_rounded">Price</span>
                                        <input type="number" class="form-control border" v-model="price"
                                            :disabled="disable_input" @input="setBuyPrices" v-if="disable_input" />
                                        <input type="number" class="form-control border" v-model="limit_price"
                                            @input="setBuyPrices" v-else />
                                        <span class="input-group-text">USDT</span>
                                    </div>
                                    <div class="input-group mb-3" :class="{ 'mt-4': disable_input }">
                                        <span class="input-group-text custom_rounded"
                                            :class="{ 'number-input': disable_input }">{{ coin }}</span>
                                        <input type="number" min="0" :step="formattedNumber" class="form-control border"
                                            v-model="coin_amount" @input="calUsdt"
                                            :class="{ 'number-input': disable_input }"
                                            :placeholder="'Enter ' + coin + ' Amount'" @click="updateRangeUi();" />
                                    </div>

                                    <div class="input-group mb-4 px-3 mt-4">
                                        <div class="mb-2 d-flex justify-content-between align-items-center w-100">
                                            <span class="text-muted">0%</span>
                                            <span class="text-muted px-2">25%</span>
                                            <span class="text-muted px-1">50%</span>
                                            <span class="text-muted px-1">75%</span>
                                            <span class="text-muted">100%</span>
                                        </div>
                                        <input type="range" class="custom-range custom-range-color"
                                            :class="{ 'my-2': disable_input }" min="0" max="100" step="1" v-model="buy_per"
                                            @change="buyPer" />
                                    </div>
                                    <div><input type="checkbox" class="me-1 tp_sl" v-model="isChecked"> TP/SL</div>


                                    <div class="mt-3" v-if="isChecked">
                                        <label class="small text-muted">Take Profit</label>
                                        <div class="input-group mb-3 border rounded-5 px-3 border-0 number-input">
                                            <input type="number" class="form-control number-input"
                                                aria-label="Text input with dropdown button">
                                            <button class="bg-transparent border-0 dropdown-toggle" type="button"
                                                data-bs-toggle="dropdown" aria-expanded="false"> {{ take_profit
                                                }}</button>
                                            <ul class="dropdown-menu dropdown-menu-end  number-input border shadow-lg">
                                                <li><a class="dropdown-item text-white" href="#"
                                                        @click="selectTakeProfit('Mark')">Mark</a></li>
                                                <li><a class="dropdown-item text-white" href="#"
                                                        @click="selectTakeProfit('Last')">Last</a></li>
                                            </ul>
                                        </div>

                                        <label class="small text-muted">Stop Loss</label>

                                        <div class="input-group mb-3 border rounded-5 px-3 border-0 number-input">
                                            <input type="number" class="form-control number-input"
                                                aria-label="Text input with dropdown button">
                                            <button class="bg-transparent border-0 dropdown-toggle" type="button"
                                                data-bs-toggle="dropdown" aria-expanded="false"> {{ stop_loss
                                                }}</button>
                                            <ul class="dropdown-menu dropdown-menu-end  number-input border shadow-lg">
                                                <li><a class="dropdown-item text-white" href="#"
                                                        @click="selectStopLoss('Mark')">Mark</a></li>
                                                <li><a class="dropdown-item text-white" href="#"
                                                        @click="selectStopLoss('Last')">Last</a></li>
                                            </ul>
                                        </div>

                                    </div>
                                    <div class="d-flex gap-3 mt-4" :class="{ 'my-3': disable_input }" v-if="auth">
                                        <button type="button"
                                            class="flex-fill bg-success w-100  text-white border-0 rounded-pill py-2"
                                            @click="buyCoin" :disabled="buy_disable">
                                            Buy/Long
                                            <div class="spinner-grow spinner-grow-sm text-light" role="status"
                                                v-if="buy_disable"></div>
                                        </button>
                                        <button type="button"
                                            class="flex-fill bg-danger w-100  text-white border-0 rounded-pill py-2"
                                            @click="sellCoin" :disabled="sell_disable">
                                            Sell/Short
                                            <div class="spinner-grow spinner-grow-sm text-light" role="status"
                                                v-if="sell_disable"></div>
                                        </button>
                                    </div>
                                    <div class="row px-2" v-if="auth">
                                        <div class="col "><small>Cost <strong>{{ total != '' ? total : 0 }}
                                                    USDT</strong></small></div>
                                        <div class="col text-end"><small>Cost <strong>{{ total_sell != '' ? total_sell :
                                                    0 }} USDT</strong></small></div>
                                    </div>
                                    <div class="row px-2" v-if="auth">
                                        <div class="col"><small>Max <strong>{{ max_coin }} {{ coin }}</strong></small>
                                        </div>
                                        <div class="col text-end"><small>Max <strong>{{ max_sell }} {{ coin
                                                    }}</strong></small></div>
                                    </div>
                                    <div class=" d-flex gap-3 mt-4" v-if="!auth">
                                        <router-link
                                            class="flex-fill  bg-white text-dark w-100   border-0 rounded-pill py-2 text-center"
                                            :to="{ name: 'Login' }">
                                            Login
                                        </router-link>
                                        <router-link
                                            class="flex-fill bg-info w-100  text-white border-0 rounded-pill py-2 text-center "
                                            :to="{ name: 'Register' }">
                                            Register
                                        </router-link>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
import marginMode from "../pages/margin_mode.vue";

export default {
    name: "future_trade_buy_sell",
    components: {
        margin_mode: marginMode,
    },
    props: {
        coin: {
            type: String,
            required: false
        },
        selectedButton: {
            type: String,
            required: false

        }
    },

    data() {
        return {
            auth: true,
            chart: null,
            url: process.env.mix_api_url,
            balance: 0,
            usdt: 0,
            price: "",
            limit_price: "",
            coin_amount: "",
            total: "",
            coin_sell: "",
            total_sell: "",
            buy_per: 0,
            sell_per: 1,
            error: false,
            toast: "hide",
            message: "",
            text: "Error",
             show: false,
            buy_disable: false,
            sell_disable: false,
            close_order: [],
            spin: true,
             symbols: [],
            data: [],
            date: [],
            chartData: [],
            coinInfo: {},
            eth: 0,
            trx: 0,
            btc: 0,
            bnb: 0,
            usd: 0,
            total_balance: 0,
              npf: 0,
             current_price: {},
            ws: null,
            disable_input: true,
            order_type: 'market',
            leverage: "1",

            final_leverage: "",
            disable: false,
            leveraging: false,
            formattedNumber: "0.0",
            coin_type: "",
            max_coin: 0,
            max_sell: 0,
            wsConnection: {},
             final_margin: 'Isolated',
            marginMode: false,
            isChecked: false,
            take_profit: 'Mark',
            stop_loss: 'Mark',

        };
    },


    created() {

        var vm = this;
        if (!this.disable_input) {
            setInterval(() => {
                vm.getPrice();
            }, 1000);
        }
        this.getPrice();

        this.coinDetails();
        this.setBalance();
        this.getSymbols();
        // this.npfPrices();
        this.getTotalBalance();
        this.getLeverages();



    },
    methods: {
        getTotalBalance() {
            axios
                .get(this.url + "api/future_total_balance", {
                    params: {
                        token: localStorage.token
                    }
                })
                .then((res) => {

                    // console.log("total_balance res "+res);

                    this.total_balance = res.data.total_balance;
                })
                .catch((err) => {
                    console.log(err);
                    if (err.response.data.message.token) {
                        this.auth = false;
                    }
                });
        },
        EnableInput(type) {
            type == 'limit' ? this.disable_input = false : this.disable_input = true;
            this.coin_sell = "";
            this.total = "";
            this.total_sell = "";
            this.buy_per = 1;
            this.sell_per = 1;
            this.order_type = type;
            this.getPrice();

            this.updateRangeUi();
        },
        getPrice() {
            if (this.coin != 'NPF') {
                axios
                    .post(this.url + "api/getFuturePrice", {
                        coin: this.coin,
                    })
                    .then((res) => {
                        var size = this.coinInfo[0].tickSize;
                        this.price = Number(res.data).toFixed(size);
                        this.limit_price = Number(res.data).toFixed(size);
                        if (this.coin_amount > 0 && this.buy_per == 0) {
                            this.calUsdt();
                        }
                        this.getSymbols();
                    })
                    .catch((err) => {
                        console.log(err);
                    });
            }
            else {
                this.npfPrices();
            }

        },
        getSymbols() {
            axios
                .post(this.url + "api/getFutureSymbols")
                .then((res) => {
                    this.symbols = res.data;
                })
                .catch((err) => {
                    console.log(err);
                });
        },
        npfPrices() {
            axios
                .post(this.url + "api/npfPrices", {
                    coin: this.coin,
                })
                .then((res) => {
                    this.data = res.data.prices;
                    this.date = res.data.date;
                    this.price = res.data.price.price;
                    this.limit_price = res.data.price.price;

                    res.data.date.forEach((ress, i) => {
                        var data = {
                            x: ress,
                            y: [res.data.data[i].open, res.data.data[i].high, res.data.data[i].low, res.data.data[i].close]
                        }
                        this.chartData.push(data);

                    });

                    // this.createChart();
                })
                .catch((err) => {
                    console.log(err);
                });
        },
        totalBuy() {
            this.error = false;
            // var stepSize = [];
            // stepSize["BNB"] = 2;
            // stepSize["BTC"] = 6;
            // stepSize["TRX"] = 1;
            this.coin_amount = this.toFixed(
                this.total / this.price,
                this.coinInfo[0].stepSize
            );
            // if (this.coin_amount > this.balance) {
            // if (this.total > this.usdt) {
            //     this.error = "Insufficient Balance";
            // }
            if (Number(this.total) > Number(this.usdt)) {
                this.error = "Insufficient Balance";
            }
        },
        coinDetails() {
            axios
                .get(this.url + "api/future_coin_details", {
                    params: {
                        coin: this.coin
                    }
                })
                .then((res) => {
                    this.coinInfo = res.data;
                })
                .catch((err) => {
                    console.log(err);
                });
        },
        calUsdt() {
            this.error = false;
            var size = this.coinInfo[0].stepSize;
            this.total = ((Number(this.price) * Number(this.coin_amount)) / Number(this.final_leverage)).toFixed(size);
            this.total_sell = this.total;
            if (this.total > Number(this.usd)) {
                this.error = "Insufficient Balance";
            }
        },
        toFixed(n, fixed) {
            return ~~(Math.pow(10, fixed) * n) / Math.pow(10, fixed);
        },
        setBuyPrices() {
            if (this.coin_amount > 0 && this.total > 0) {
                var size = this.coinInfo[0].stepSize;
                if (this.coin == "NPF") {
                    size = 0;
                }
                this.coin_amount = this.toFixed(
                    this.total / this.price,
                    size
                );

                if (this.total > this.usdt) {
                    this.error = "Insufficient Balance1";
                }
            }
        },
        buyPer() {
            this.coin_type = "per";
            this.error = false;
            // var size = stepSize[this.coin];
            var size = this.coinInfo[0].stepSize;

            var val = this.buy_per;
            var amount = this.usd * (val / 100);
            this.total = (amount).toFixed(size);

            this.coin_amount = this.fix(((amount / this.price) * this.final_leverage), size);

            // this.total_sell = Number(((this.balance*(val/100))*this.price)*this.final_leverage).toFixed(2);
            // if(this.balance == 0){
            this.total_sell = this.total;
            // }


        },
        fix(value, decimals) {
            const factor = Math.pow(10, decimals);
            return (Math.floor(value * factor) / factor).toFixed(decimals);
        },


        subLev() {
            if (this.leverage > 0) {
                this.leverage = Number(this.leverage) - 1;

                const rangeInput_id = document.getElementById('rangeInput');
                const percentage = (this.leverage / rangeInput_id.max) * 100;
                rangeInput_id.style.background = `linear-gradient(to right, #24d1e5 ${percentage}%, #e5e5e5 ${percentage}%)`;
            }
        },
        addLev() {
            if (this.leverage < 125) {
                this.leverage = Number(this.leverage) + 1;

                const rangeInput_id = document.getElementById('rangeInput');
                const percentage = (this.leverage / rangeInput_id.max) * 100;
                rangeInput_id.style.background = `linear-gradient(to right, #24d1e5 ${percentage}%, #e5e5e5 ${percentage}%)`;
            }
        },
        selectTakeProfit(item) {
            this.take_profit = item;
        },
        selectStopLoss(item) {
            this.stop_loss = item;
        },

        getLeverages() {
            axios
                .get(this.url + "api/getLeverage", {
                    params: {
                        token: localStorage.token,
                        coin: this.coin
                    }
                })
                .then((res) => {

                    this.leverage = res.data.leverage;
                    this.final_leverage = res.data.leverage;
                    this.final_margin = res.data.margin;
                })
                .catch((err) => {
                    console.log(err);
                });
        },
        setLeverage() {
            this.leveraging = true;
            axios.post(this.url + "api/setLeverage", {
                token: localStorage.token,
                coin: this.coin,
                leverage: this.leverage
            }).then(res => {
                // console.log(res);
                this.getLeverages();
                this.$toaster.success(res.data.message);
                this.leveraging = false;
                $(".btn-close").click();
            }).catch(err => {
                this.$toaster.error(err.response.data.message);
                this.leveraging = false;
            });
        },
        buyCoin() {
            if (confirm("Are you sure want to Buy!")) {

                var link = this.url + "api/manualFutureBuy";
                if (this.order_type == 'limit') {
                    link = this.url + "api/limitBuyOrder";
                    // this.$toaster.info("coming soon");
                    // return false;
                }
                this.buy_disable = true;
                axios
                    .post(link, {
                        quantity: this.coin_amount,
                        coin: this.coin,
                        leverage: this.final_leverage,
                        token: localStorage.token,
                        coin_type: this.coin_type,
                        price: this.price,
                        stop_loss:this.stop_loss,
                        take_profit:this.take_profit,
                        margin_mode:this.final_margin




                    })
                    .then((res) => {
                        // console.log(res.data);
                        this.buy_per = 1;
                        this.setBalance();
                        this.markPrice(this.coin + "USDT");
                        this.updateRangeUi();
                        //    this.order_type == 'limit'? this.openOrders(): this.orderHistory();
                        var message = res.data.message;
                        this.$toaster.success(message);
                        this.stop_loss="";
                        this.take_profit="";
                        this.coin_amount = "";
                        this.total = "";
                        this.total_sell = "";
                        this.buy_disable = false;
                    })
                    .catch((err) => {
                        console.log(err);
                        var message = err.response.data.message;

                        if (typeof (message) == 'object') {
                            Object.values(message).forEach(msg => {
                                this.$toaster.error(msg[0]);
                            });
                        }
                        else {
                            this.$toaster.error(message);
                        }
                        this.coin_amount = "";
                        this.total = "";
                        this.total_sell = "";
                        this.buy_per = 0;
                        this.buy_disable = false;
                        this.updateRangeUi();

                    });
            }
        },

        async setBalance() {
            this.usdt = await this.getBalance("epin");
            this.usd = await this.getBalance("usd");
            this.bnb = await this.getBalance("BNB");
            this.btc = await this.getBalance("BTC");
            this.trx = await this.getBalance("TRX");
            this.eth = await this.getBalance("ETH");
            this.npf = await this.getBalance("NPF");
            this.balance = await this.getBalance(this.coin);
            this.max_coin = Number(((this.usd * this.final_leverage) / this.price).toFixed(4));

            this.max_sell = this.max_coin;
        },

        async getBalance(coin) {

            var res = await axios
                .post(this.url + "api/coinFutureBalance", {
                    coin: coin,
                    token: localStorage.token,
                });

            return res.data;


        },
        // sell trade
        sellCoin() {
            if (confirm("Are you sure want to Sell!")) {

                var link = this.url + "api/manualFutureSell";
                if (this.order_type == 'limit') {
                    link = this.url + "api/limitSellOrder";
                    // this.$toaster.info("coming soon");
                    // return false;
                }
                this.sell_disable = true;
                axios
                    .post(link, {
                        quantity: this.coin_amount,
                        coin: this.coin,
                        token: localStorage.token,
                        leverage: this.leverage,
                        coin_type: this.coin_type,
                        price: this.price,
                        margin_mode:this.final_margin

                    })
                    .then((res) => {
                        // console.log(res);
                        this.sell_disable = false;
                        this.setBalance();
                        this.getTotalBalance();
                        this.markPrice(this.coin + "USDT");
                        this.positionHistory();
                        this.updateRangeUi();
                        this.getTotalBalance();
                        var message = res.data.message;
                        this.$toaster.success(message);
                        this.coin_amount = "";
                    })
                    .catch((err) => {
                        console.log(err);
                        var message = err.response.data.message;
                        if (typeof (message) == 'object') {
                            Object.values(message).forEach(msg => {
                                this.$toaster.error(msg[0]);
                            });
                        }
                        else {
                            this.$toaster.error(message);
                        }
                        this.coin_amount = "";
                        this.sell_disable = false;
                        this.updateRangeUi();

                    });
            }
        },
        updateRangeUi() {
            this.coin_type = "";
            this.formattedNumber = 10 / Math.pow(10, this.coinInfo[0].stepSize);
            this.coin_amount = ''; this.total = ''; this.buy_per = 0;
            const rangeInputs = document.querySelectorAll('.custom-range-color');
            rangeInputs.forEach(rangeInput => {
                const percentage = 0;
                rangeInput.style.background = `linear-gradient(to right, #24d1e5 ${percentage}%, #e5e5e5 ${percentage}%)`;
            });
        },
        markPrice(asset) {

            if (this.wsConnection[asset]) {
                return this.current_price[asset] || "Loading"; // Reuse the existing connection
            }
            if (asset != "NPFUSDT") {
                const symbol = asset.toLowerCase();

                const ws = new WebSocket(
                    `wss://fstream.binance.com/ws/${symbol}@ticker`
                );
                ws.onmessage = (event) => {
                    const data = JSON.parse(event.data);
                    this.$set(this.current_price, asset, data.c);
                };

                this.$set(this.wsConnection, asset, ws);
            }
            else {
                this.$set(this.current_price, asset, this.price);
            }

            return this.current_price[asset] || "Loading";
        },
    },

    mounted() {
        var vm = this;
        const rangeInputs = document.querySelectorAll('.custom-range-color');
        rangeInputs.forEach(rangeInput => {
            function updateBackground(value) {
                const percentage = (value / rangeInput.max) * 100;
                rangeInput.style.background = `linear-gradient(to right, #24d1e5 ${percentage}%, #e5e5e5 ${percentage}%)`;
            }

            updateBackground(rangeInput.value);

            rangeInput.addEventListener('input', (e) => {
                updateBackground(e.target.value);
            });
        });
        const rangeInput_id = document.getElementById('rangeInput');
        function updateBackgroundId(value) {
            const percentage = (value / rangeInput_id.max) * 100;
            rangeInput_id.style.background = `linear-gradient(to right, #24d1e5 ${percentage}%, #e5e5e5 ${percentage}%)`;
        }

         updateBackgroundId(rangeInput_id.value);
        rangeInput_id.addEventListener('input', (e) => {
            updateBackgroundId(e.target.value);
        });

    }
};
</script>

<style scoped>
.nav-link {
    color: white !important;
}

.cstm_dropdown {
    background-color: #052133 !important;
    color: white !important;
}


.card {
    color: white !important;
    background-color: #052133;
    /*  border-color: #092940 !important; */
    border: 1px solid Var(--primary-color) !important
}

.card.card-body {
    background-color: #052133 !important;
    color: white !important;
}

.card.card-header {
    background-color: #052133;
    color: white !important;
}

.input-group> :not(:first-child):not(.dropdown-menu):not(.valid-tooltip):not(.valid-feedback):not(.invalid-tooltip):not(.invalid-feedback) {
    background-color: #052133;
    color: white !important;
    border-color: #092940 !important;
}

.input-group:not(.has-validation)> :not(:last-child):not(.dropdown-toggle):not(.dropdown-menu):not(.form-floating),
.input-group:not(.has-validation)>.dropdown-toggle:nth-last-child(n + 3),
.input-group:not(.has-validation)>.form-floating:not(:last-child)>.form-control,
.input-group:not(.has-validation)>.form-floating:not(:last-child)>.form-select {
    background-color: #052133;
    color: white !important;
    border-color: #092940 !important;
}

.form-control {
    background-color: #052133;
    color: white !important;
    border-color: #092940 !important;
}

.form-control:focus {
    background-color: #052133;
    color: white !important;
    border-color: #092940 !important;
}


@keyframes backgroundColorAnimation {
    0% {
        background-position: 100% 0;
    }

    100% {
        background-position: 0 0;
    }
}

.number-input {
    background-color: #536179 !important;
    animation: backgroundColorAnimation 1s forwards;

}

.custom_rounded {
    border-top-left-radius: 20px !important;
    border-bottom-left-radius: 20px !important;

}


.custom-range {
    -webkit-appearance: none;
    appearance: none;
    width: 100%;
    height: 5px;
    cursor: pointer;
    background: #e5e5e5;
    border-radius: 5px;
    outline: none;
}

.custom-range::-webkit-slider-runnable-track {
    height: 5px;
}

.custom-range::-webkit-slider-thumb {
    -webkit-appearance: none;
    appearance: none;
    width: 10px;
    height: 10px;
    background: #24d1e5;
    margin-top: -3px;
    border-radius: 10%;

    cursor: pointer;
    transform: rotate(45deg) !important;
    transform-origin: center;
}

.custom-range::-moz-range-thumb {
    width: 10px;
    height: 10px;
    background: #24d1e5;
    border-radius: 10%;
    cursor: pointer;
}

.custom-range::-ms-thumb {
    width: 10px;
    height: 10px;
    background: #24d1e5;
    border-radius: 10%;
    cursor: pointer;
}

::-webkit-scrollbar {
    height: 5px;
    width: 5px;
}

::-webkit-scrollbar-track {
    border-radius: 10px;
}

::-webkit-scrollbar-thumb {
    background: #686868;
    border-radius: 10px;
}

::-webkit-scrollbar-thumb:hover {
    background: #686868;
}

input[type='checkbox'] {
    accent-color: #ffffff !important;
}
</style>
