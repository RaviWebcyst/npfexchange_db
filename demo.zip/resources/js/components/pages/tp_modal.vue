<template>

<div>

    <div  v-if="screen == 'mobile'" class="modal fade "  id="mobiletpslmodal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="tpslmodalLabel" aria-hidden="true">
        <div class="modal-dialog centered " style="margin-top:150px">
            <div class="modal-content bg-dark">
                <div class="modal-header">
                    <h5 class="modal-title" id="transfer_usdt">TP/SL for entire position
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                        aria-label="Close" ></button>
                </div>
                <div class="modal-body" >
                  <div class="d-flex   justify-content-between small mt-2">
                      <span class="  text-muted">Symbol </span>
                      <span> {{coin}}USDT Perpetual / {{ type == "Buy" ? 'Long' : 'Short' }} {{ leverage }}x</span>
                  </div>
                  <div class="d-flex   justify-content-between small mt-2">
                      <span class="  text-muted">Entry Price </span>
                      <span> 00 USDT</span>
                  </div>
                  <div class="d-flex border-bottom pb-3  justify-content-between small mt-2">
                      <span class="  text-muted">Mark Price </span>
                      <span>  00 USDT</span>
                  </div>
                  <div class="mb-3  ">
                      <label for="takeProfit" class="form-label   small mt-4 ">Take Profit</label>
                      <div class="input-group">
                        <input type="text" class="form-control border w-75 number-input" id="takeProfit">
                        <select class="form-control border number-input">
                          <option selected>Mark</option>
                          <option value="1">PnL</option>
                        </select>
                      </div>
                      <div class="small text-muted mt-2">
                          When Mark Price reaches 0.0000, it will trigger Take Profit Market <br> order to close this position. Estimated PNL will be -- USDT
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="stopLoss" class="form-label   small  ">Stop Loss</label>
                        <div class="input-group ">
                        <input type="text" class="form-control border w-75 number-input" id="stopLoss">
                        <select class="form-control border number-input"  >
                          <option selected>Mark</option>
                          <option value="1">PnL</option>
                        </select>
                      </div>
                      <div class="small text-muted mt-2">
                          When Mark Price reaches 0.0000, it will trigger Stop Market order to <br> close this position. Estimated PNL will be -- USDT
                      </div>
                    </div>
                    <div class="mt-3">
                       <label class="form-check-label small" for="hideSymbols"> <i class="fas fa-info-circle"></i> What is position TP/SL</label>
                    </div>

                    <div class="d-flex justify-content-center">
                        <button class="btn butn rounded text-dark mb-4 mt-3 w-75" type="button" :disabled="tp_loading">Confirm
                            <span class="spinner-grow spinner-grow-sm pl-2" role="status" aria-hidden="true" v-if="tp_loading" ></span>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>





    <div v-if="screen == 'desktop'" class="modal fade" id="desktoptpslmodal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="desktoptpslmodalLabel" aria-hidden="true">
        <div class="modal-dialog centered " style="margin-top:150px">
            <div class="modal-content bg-dark">
                <div class="modal-header">
                    <h5 class="modal-title" id="transfer_usdt">TP/SL for entire position
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" ></button>
                </div>
                <div class="modal-body" >
                  <div class="d-flex   justify-content-between small mt-2">
                      <span class="  text-muted">Symbol </span>
                      <span> {{coin}}USDT Perpetual / {{ type == "Buy" ? 'Long' : 'Short' }} {{ leverage }}x</span>
                  </div>
                  <div class="d-flex   justify-content-between small mt-2">
                      <span class="  text-muted">Entry Price </span>
                      <span> 00 USDT</span>
                  </div>
                  <div class="d-flex border-bottom pb-3  justify-content-between small mt-2">
                      <span class="  text-muted">Mark Price </span>
                      <span>  00 USDT</span>
                  </div>
                  <div class="mb-3  ">
                      <label for="takeProfit" class="form-label   small mt-4 ">Take Profit</label>
                      <div class="input-group">
                        <input type="text" class="form-control border w-75 number-input" id="takeProfit">
                        <select class="form-control border number-input">
                          <option selected>Mark</option>
                          <option value="1">PnL</option>
                        </select>
                      </div>
                      <div class="small text-muted mt-2">
                          When Mark Price reaches 0.0000, it will trigger Take Profit Market <br> order to close this position. Estimated PNL will be -- USDT
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="stopLoss" class="form-label   small  ">Stop Loss</label>
                        <div class="input-group ">
                        <input type="text" class="form-control border w-75 number-input" id="stopLoss">
                        <select class="form-control border number-input"  >
                          <option selected>Mark</option>
                          <option value="1">PnL</option>
                        </select>
                      </div>
                      <div class="small text-muted mt-2">
                          When Mark Price reaches 0.0000, it will trigger Stop Market order to <br> close this position. Estimated PNL will be -- USDT
                      </div>
                    </div>
                    <div class="mt-3">
                       <label class="form-check-label small" for="hideSymbols"> <i class="fas fa-info-circle"></i> What is position TP/SL</label>
                    </div>

                    <div class="d-flex justify-content-center">
                        <button class="btn butn rounded text-dark mb-4 mt-3 w-75" type="button" :disabled="tp_loading">Confirm
                            <span class="spinner-grow spinner-grow-sm pl-2" role="status" aria-hidden="true" v-if="tp_loading" ></span>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</template>

<script>

export default {
    name: "margin_mode",

    props: {
        coin: String,
    leverage: Number,
    type: String,
    id: String,
    screen : String,
  },

    data() {
        return {
            url: process.env.mix_api_url,
             tp_loading:false,

        };
    },
    mounted(){

    },
    methods: {


    },
};
</script>

<style scoped>
@keyframes backgroundColorAnimation {
    0% {
      background-position: 100% 0;
    }
    100% {
      background-position: 0 0;
    }
  }

.number-input {
    background-color: #536179 !important;
    animation: backgroundColorAnimation 1s forwards;

}
.input-group:not(.has-validation)> :not(:last-child):not(.dropdown-toggle):not(.dropdown-menu):not(.form-floating),
.input-group:not(.has-validation)>.dropdown-toggle:nth-last-child(n + 3),
.input-group:not(.has-validation)>.form-floating:not(:last-child)>.form-control,
.input-group:not(.has-validation)>.form-floating:not(:last-child)>.form-select {
    background-color: #052133;
    color: white !important;
    border-color: #092940 !important;
}

div.dataTables_wrapper div.dataTables_length select {
    background-color: #052133;
    color: white !important;
    border-color: #092940 !important;
}

.form-control {
    background-color: #052133;
    color: white !important;
    border-color: #092940 !important;
}

.form-control:focus {
    background-color: #052133;
    color: white !important;
    border-color: #092940 !important;
}

.main {
    background-color: #151a25 !important;
    color: white !important;
    border-color: #151a25 !important;
}

.layout-with-border-radius .layout__area--right:not(.no-border-top-left-radius) .widgetbar-pages,
.layout-with-border-radius .layout__area--right:not(.no-border-top-left-radius) .widgetbar-pages.hidden+.widgetbar-tabs,
.layout-with-border-radius .layout__area--right:not(.no-border-top-left-radius) .widgetbar-widget:first-child {
    background-color: 052133 !important;
    color: white !important;
}

.page-item.disabled .page-link {
    background-color: #24d1e5 !important;
    color: white !important;
    border-color: #24d1e5 !important;
}

.page-item.active .page-link {
    background-color: #24d1e5 !important;
    color: white !important;
    border-color: #24d1e5 !important;
}

</style>
