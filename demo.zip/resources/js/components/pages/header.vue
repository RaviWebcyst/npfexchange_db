<template>
    <div style="margin-top:38px; "   :style="{ marginBottom: auth == false ? '75px' : '50px' }">
        <nav class="bg-main py-2 fixed-top sticky-top position-fixed" v-if="auth == false">
            <div class="container">
                <div class="row">
                    <div class="col-2 d-none d-md-block">
                        <div class="d-flex gap-1 ">
                            <i class="fa fa-life-ring  text-black my-auto"></i>
                            <p class="text-black my-auto">Contact Support</p>
                        </div>
                    </div>
                    <div class="col d-none d-md-block">
                        <div class="d-flex gap-1 ">
                            <i class="fa fa-pie-chart  text-black my-auto"></i>
                            <p class="text-black my-auto"> Trading Fees: 0.05% Taker / -0.54% Market</p>
                        </div>
                    </div>
                    <div class="col d-none d-md-block">
                        <div class="d-flex gap-2 float-end">
                            <router-link class="text-black" :to="{ name: 'Login' }"> <i
                                    class="fa fa-sign-in pe-1"></i>Login</router-link>
                            <router-link class="text-black" :to="{ name: 'Register' }"> <i
                                    class="fa fa-lock pe-1"></i>Register</router-link>
                        </div>

                    </div>
                    <div class="col d-flex d-md-none justify-content-center">
                        <div class="d-flex gap-2 float-end">
                            <router-link class="text-black" :to="{ name: 'Login' }"> <i
                                    class="fa fa-sign-in pe-1"></i>Login</router-link>
                            <router-link class="text-black" :to="{ name: 'Register' }"> <i
                                    class="fa fa-lock pe-1"></i>Register</router-link>
                        </div>

                    </div>
                </div>
            </div>
        </nav>
        <nav class="navbar navbar-expand-lg bg-main_dark fixed-top shadow py-2 sticky-top px-3 position-fixed"   :style="{ marginTop: auth == false ? '38px' : '0px' }" >
            <div class="container " >
                <router-link class="navbar-brand text-white" :to="{ name: 'index' }">
                        <img v-if="logo" :src="apiUrl + 'uploads/logo/' + logo" alt="" width="100" height="50">
                        <img v-else :src="apiUrl + 'logo.png'" alt="" width="100">
                        <span class="gradient-text-primary-secondary ms-2"></span>

                </router-link>

<div>
    <button v-if="auth == true"  class="navbar-toggler border-0 text-white" type="button" data-bs-toggle="offcanvas"
    data-bs-target="#offcanvasExample2" aria-controls="offcanvasNavbar">
    <i class="ri-user-3-fill fs-5"></i>
    </button>

    <button  class="navbar-toggler border-0 text-white" type="button" data-bs-toggle="offcanvas"
    data-bs-target="#offcanvasNavbar" aria-controls="offcanvasNavbar">
    <i class="ri-menu-2-line fs-4 fw-bold"></i>
</button>

</div>
                <div class="offcanvas offcanvas-start w-75 bg-black" tabindex="-1" id="offcanvasNavbar"
                    aria-labelledby="offcanvasNavbarLabel">
                    <div class="offcanvas-header">
                        <button type="button" class="btn-close ms-auto" data-bs-dismiss="offcanvas"
                            aria-label="Close"></button>
                    </div>
                    <div class="offcanvas-body">
                        <ul class="navbar-nav mb-2 mb-lg-0 align-items-center col">
                            <li class="nav-item mx-1 d-md-none">
                                <router-link class="navbar-brand text-white mb-3" :to="{ name: 'index' }">
                                    <img v-if="logo" :src="apiUrl + 'uploads/logo/' + logo" alt="" width="100" height="50">
                                    <img v-else :src="apiUrl + 'logo.png'" alt="" width="100">
                                </router-link>
                            </li>
                            <!-- <li class="nav-item mx-1 dropdown">
                                <a class="nav-link text-white nav_margin dropdown-toggle" href="#" role="button"
                                    data-bs-toggle="dropdown" aria-expanded="false" :class="{ 'show': dropToggle }"
                                    @click="dropdowns">
                                    <img :src="apiUrl+'icons/npficon.svg'" alt="" width="20">
                                </a>
                                <ul class="dropdown-menu p-3 grid_nav grid_nav_transform" :class="{ 'show': dropToggle }">
                                    <div class="row">
                                        <div class="col-lg-4">
                                            <a href="#">
                                                <div class="row align-items-center mb-3 nav_hover gap-2 py-2">
                                                    <div class="col-2">
                                                        <i class="ri-swap-line text-main fs-2"></i>
                                                    </div>
                                                    <div class="col-8">
                                                        <p class="mb-0">Exchange</p>
                                                        <p class="mb-0" style="font-size: 10px;">Blockchain and crypto
                                                            assest exchange.</p>
                                                    </div>
                                                </div>
                                            </a>
                                            <a href="#">
                                                <div class="row align-items-center mb-3 nav_hover p-2">
                                                    <div class="col-2">
                                                        <i class="fa-solid fa-hands-holding-child text-main fs-5"></i>
                                                    </div>
                                                    <div class="col-8">
                                                        <p class="mb-0">Charity</p>
                                                        <p class="mb-0" style="font-size: 10px;">Powering blockchain for
                                                            good.</p>
                                                    </div>
                                                </div>
                                            </a>
                                            <a href="#">
                                                <div class="row align-items-center mb-3 nav_hover p-2">
                                                    <div class="col-2">
                                                        <i class="fa-solid fa-flask-vial fs-5 text-main"></i>
                                                    </div>
                                                    <div class="col-8">
                                                        <p class="mb-0">Labs</p>
                                                        <p class="mb-0" style="font-size: 10px;">Incubator for top
                                                            blockchains projects.</p>
                                                    </div>
                                                </div>
                                            </a>
                                            <a href="#">
                                                <div class="row align-items-center mb-3 nav_hover p-2">
                                                    <div class="col-2">
                                                        <i class="fa-solid fa-wallet fs-5 text-main"></i>
                                                    </div>
                                                    <div class="col-8">
                                                        <p class="mb-0">Defi Wallet</p>
                                                        <p class="mb-0" style="font-size: 10px;">Meet the next-generation
                                                            Web3 wallet.</p>
                                                    </div>
                                                    <div class="col-2">
                                                        <i class="ri-arrow-right-line right_arrow_nav text-main"></i>
                                                    </div>
                                                </div>
                                            </a>
                                        </div>
                                        <div class="col-lg-4">
                                            <a href="#">
                                                <div class="row align-items-center mb-3 nav_hover p-2">
                                                    <div class="col-2">
                                                        <i class="fa-solid fa-graduation-cap fs-5 text-main"></i>
                                                    </div>
                                                    <div class="col-8">
                                                        <p class="mb-0">Academy</p>
                                                        <p class="mb-0" style="font-size: 10px;">Blockchain and crypto
                                                            education.</p>
                                                    </div>
                                                    <div class="col-2">
                                                        <i class="ri-arrow-right-line right_arrow_nav text-main"></i>
                                                    </div>
                                                </div>
                                            </a>
                                            <a href="#">
                                                <div class="row align-items-center mb-3 nav_hover p-2">
                                                    <div class="col-2">
                                                        <i class="fa-solid fa-cloud fs-5 text-main"></i>
                                                    </div>
                                                    <div class="col-8">
                                                        <p class="mb-0">Cloud</p>
                                                        <p class="mb-0" style="font-size: 10px;">Enterprise exchange
                                                            solutions.</p>
                                                    </div>
                                                    <div class="col-2">
                                                        <i class="ri-arrow-right-line right_arrow_nav text-main"></i>
                                                    </div>
                                                </div>
                                            </a>
                                            <a href="#">
                                                <div class="row align-items-center mb-3 nav_hover p-2">
                                                    <div class="col-2">
                                                        <i class="fa-solid fa-rocket fs-5 text-main"></i>
                                                    </div>
                                                    <div class="col-8">
                                                        <p class="mb-0">LaunchPad</p>
                                                        <p class="mb-0" style="font-size: 10px;">Token Launch Plateform.</p>
                                                    </div>
                                                    <div class="col-2">
                                                        <i class="ri-arrow-right-line right_arrow_nav text-main"></i>
                                                    </div>
                                                </div>
                                            </a>
                                            <a href="#">
                                                <div class="row align-items-center mb-3 nav_hover p-2">
                                                    <div class="col-2">
                                                        <i class="ri-swap-line text-main fs-2"></i>
                                                    </div>
                                                    <div class="col-8">
                                                        <p class="mb-0">BABT</p>
                                                        <p class="mb-0" style="font-size: 10px;">Verified user credentials
                                                            fort the Web3 era.</p>
                                                    </div>
                                                    <div class="col-2">
                                                        <i class="ri-arrow-right-line right_arrow_nav text-main"></i>
                                                    </div>
                                                </div>
                                            </a>
                                            <a href="#">
                                                <div class="row align-items-center mb-3 nav_hover p-2">
                                                    <div class="col-2">
                                                        <i class="fa-solid fa-circle-notch fs-5 text-main"></i>
                                                    </div>
                                                    <div class="col-8">
                                                        <p class="mb-0">OTC Trading</p>
                                                        <p class="mb-0" style="font-size: 10px;">Spot,Options,Algo Orders
                                                            and more.</p>
                                                    </div>
                                                    <div class="col-2">
                                                        <i class="ri-arrow-right-line right_arrow_nav text-main"></i>
                                                    </div>
                                                </div>
                                            </a>
                                        </div>
                                        <div class="col-lg-4">
                                            <a href="#">
                                                <div class="row align-items-center mb-3 nav_hover p-2">
                                                    <div class="col-2">
                                                        <i class="fa-brands fa-leanpub fs-5 text-main"></i>
                                                    </div>
                                                    <div class="col-8">
                                                        <p class="mb-0">Learn & Earn</p>
                                                        <p class="mb-0" style="font-size: 10px;">Earn free crypto through
                                                            learning.</p>
                                                    </div>
                                                    <div class="col-2">
                                                        <i class="ri-arrow-right-line right_arrow_nav text-main"></i>
                                                    </div>
                                                </div>
                                            </a>
                                            <a href="#">
                                                <div class="row align-items-center mb-3 nav_hover p-2">
                                                    <div class="col-2">
                                                        <i class="fa-solid fa-box fs-5 text-main"></i>
                                                    </div>
                                                    <div class="col-8">
                                                        <p class="mb-0">DEX</p>
                                                        <p class="mb-0" style="font-size: 10px;">Fast and secure
                                                            decentralized digital asset exchange.</p>
                                                    </div>
                                                    <div class="col-2">
                                                        <i class="ri-arrow-right-line right_arrow_nav text-main"></i>
                                                    </div>
                                                </div>
                                            </a>
                                            <a href="#">
                                                <div class="row align-items-center mb-3 nav_hover p-2">
                                                    <div class="col-2">
                                                        <i class="fa-solid fa-microscope fs-5 text-main"></i>
                                                    </div>
                                                    <div class="col-8">
                                                        <p class="mb-0">Research</p>
                                                        <p class="mb-0" style="font-size: 10px;">Insitutional-grade analysis
                                                            and reports.</p>
                                                    </div>
                                                    <div class="col-2">
                                                        <i class="ri-arrow-right-line right_arrow_nav text-main"></i>
                                                    </div>
                                                </div>
                                            </a>
                                            <a href="#">
                                                <div class="row align-items-center mb-3 nav_hover p-2">
                                                    <div class="col-2">
                                                        <i class="fa-solid fa-file fs-5 text-main"></i>
                                                    </div>
                                                    <div class="col-8">
                                                        <p class="mb-0">npf Tax</p>
                                                        <p class="mb-0" style="font-size: 10px;">Free tax tool to calculate
                                                            your crypto taxes.</p>
                                                    </div>
                                                    <div class="col-2">
                                                        <i class="ri-arrow-right-line right_arrow_nav text-main"></i>
                                                    </div>
                                                </div>
                                            </a>
                                            <a href="#">
                                                <div class="row align-items-center mb-3 nav_hover p-2">
                                                    <div class="col-2">
                                                        <i class="fa-solid fa-tarp-droplet fs-5 text-main"></i>
                                                    </div>
                                                    <div class="col-8">
                                                        <p class="mb-0">Accept Crypto Payment</p>
                                                        <p class="mb-0" style="font-size: 10px;">Allow your customer to pay
                                                            with crypto.</p>
                                                    </div>
                                                    <div class="col-2">
                                                        <i class="ri-arrow-right-line right_arrow_nav text-main"></i>
                                                    </div>
                                                </div>
                                            </a>
                                        </div>
                                    </div>
                                </ul>
                            </li>
                            <li class="nav-item mx-1 dropdown">
                                <a class="nav-link text-white nav_margin dropdown-toggle" href="#" role="button"
                                    data-bs-toggle="dropdown" aria-expanded="false">
                                    Trade
                                </a>
                                <ul class="dropdown-menu p-3 grid_nav_transform" style="width: 600px;">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <router-link :to="{ name: 'trade' }">
                                                <div class="row align-items-center mb-3 nav_hover p-2">
                                                    <div class="col-2">
                                                        <i class="fa-solid fa-trowel-bricks text-main fs-5"></i>
                                                    </div>
                                                    <div class="col-8">
                                                        <p class="mb-0">Spot</p>
                                                        <p class="mb-0" style="font-size: 10px;">Trade crypto with advanced
                                                            tools </p>
                                                    </div>
                                                    <div class="col-2">
                                                        <i class="ri-arrow-right-line right_arrow_nav text-main"></i>
                                                    </div>
                                                </div>
                                            </router-link>
                                            <a href="#">
                                                <div class="row align-items-center mb-3 nav_hover p-2">
                                                    <div class="col-2">
                                                        <i class="ri-swap-line text-main fs-2"></i>
                                                    </div>
                                                    <div class="col-8">
                                                        <p class="mb-0">Npf Convert</p>
                                                        <p class="mb-0" style="font-size: 10px;">The easiest way to trade.
                                                        </p>
                                                    </div>
                                                    <div class="col-2">
                                                        <i class="ri-arrow-right-line right_arrow_nav text-main"></i>
                                                    </div>
                                                </div>
                                            </a>
                                            <a href="#">
                                                <div class="row align-items-center mb-3 nav_hover p-2">
                                                    <div class="col-2">
                                                        <i class="fa-solid fa-percent text-main fs-5"></i>
                                                    </div>
                                                    <div class="col-8">
                                                        <p class="mb-0">Margin</p>
                                                        <p class="mb-0" style="font-size: 10px;">Increase your profit with
                                                            leverage</p>
                                                    </div>
                                                    <div class="col-2">
                                                        <i class="ri-arrow-right-line right_arrow_nav text-main"></i>
                                                    </div>
                                                </div>
                                            </a>
                                            <a href="#">
                                                <div class="row align-items-center mb-3 nav_hover p-2">
                                                    <div class="col-2">
                                                        <i class="fa-solid fa-robot text-main fs-5"></i>
                                                    </div>
                                                    <div class="col-8">
                                                        <p class="mb-0">Trading Bots</p>
                                                        <p class="mb-0" style="font-size: 10px;">Trade smater with the
                                                            various automated statergies-easy,fast and reliable.</p>
                                                    </div>
                                                    <div class="col-2">
                                                        <i class="ri-arrow-right-line right_arrow_nav text-main"></i>
                                                    </div>
                                                </div>
                                            </a>
                                        </div>
                                        <div class="col-lg-6">
                                            <router-link :to="{name:'p2p'}">
                                                <div class="row align-items-center mb-3 nav_hover p-2">
                                                    <div class="col-2">
                                                        <i class="fa-solid fa-person-military-to-person text-main fs-5"></i>
                                                    </div>
                                                    <div class="col-8">
                                                        <p class="mb-0">P2P</p>
                                                        <p class="mb-0" style="font-size: 10px;">Bank Transfer and 100+
                                                            options</p>
                                                    </div>
                                                    <div class="col-2">
                                                        <i class="ri-arrow-right-line right_arrow_nav text-main"></i>
                                                    </div>
                                                </div>
                                            </router-link>
                                            <a href="#">
                                                <div class="row align-items-center mb-3 nav_hover p-2">
                                                    <div class="col-2">
                                                        <i class="fa-solid fa-repeat text-main fs-5"></i>
                                                    </div>
                                                    <div class="col-8">
                                                        <p class="mb-0">Swap Farming</p>
                                                        <p class="mb-0" style="font-size: 10px;">Swap to Earn npf</p>
                                                    </div>
                                                    <div class="col-2">
                                                        <i class="ri-arrow-right-line right_arrow_nav text-main"></i>
                                                    </div>
                                                </div>
                                            </a>
                                            <a href="#">
                                                <div class="row align-items-center mb-3 nav_hover p-2">
                                                    <div class="col-2">
                                                        <i class="fa-solid fa-ranking-star text-main fs-5"></i>

                                                    </div>
                                                    <div class="col-8">
                                                        <p class="mb-0">Fan Token</p>
                                                        <p class="mb-0" style="font-size: 10px;">Upgrade your fan experience
                                                        </p>
                                                    </div>
                                                    <div class="col-2">
                                                        <i class="ri-arrow-right-line right_arrow_nav text-main"></i>
                                                    </div>
                                                </div>
                                            </a>
                                            <a href="#">
                                                <div class="row align-items-center mb-3 nav_hover p-2">
                                                    <div class="col-2">
                                                        <i class="fa-solid fa-cubes-stacked text-main fs-5"></i>
                                                    </div>
                                                    <div class="col-8">
                                                        <p class="mb-0">OTC Block Trading</p>
                                                        <p class="mb-0" style="font-size: 10px;">RFQ and trade large spot
                                                            orders</p>
                                                    </div>
                                                    <div class="col-2">
                                                        <i class="ri-arrow-right-line right_arrow_nav text-main"></i>
                                                    </div>
                                                </div>
                                            </a>
                                        </div>
                                    </div>
                                </ul>
                            </li>
                            <li class="nav-item mx-1 dropdown">
                                <a class="nav-link text-white nav_margin dropdown-toggle" href="#" role="button"
                                    data-bs-toggle="dropdown" aria-expanded="false">
                                    Buy Crypto
                                </a>
                                <ul class="dropdown-menu p-3 grid_nav_transform" style="width: 300px">
                                    <div>
                                        <a href="#">
                                            <div class="row align-items-center mb-3 nav_hover p-2">
                                                <div class="col-2">
                                                    <i class="fa-solid fa-credit-card text-main fs-5"></i>
                                                </div>
                                                <div class="col-8">
                                                    <p class="mb-0">Credit/Debit Card</p>
                                                    <p class="mb-0" style="font-size: 10px;">Buy crypto via card</p>
                                                </div>
                                                <div class="col-2">
                                                    <i class="ri-arrow-right-line right_arrow_nav text-main"></i>
                                                </div>
                                            </div>
                                        </a>
                                        <a href="#">
                                            <div class="row align-items-center mb-3 nav_hover p-2">
                                                <div class="col-2">
                                                    <i class="fa-solid fa-person-military-to-person text-main fs-5"></i>
                                                </div>
                                                <div class="col-8">
                                                    <p class="mb-0">P2P Trading</p>
                                                    <p class="mb-0" style="font-size: 10px;">Bank transfer and 100+ options
                                                    </p>
                                                </div>
                                                <div class="col-2">
                                                    <i class="ri-arrow-right-line right_arrow_nav text-main"></i>
                                                </div>
                                            </div>
                                        </a>
                                                <div class="row align-items-center mb-3 nav_hover p-2">
                                                    <div class="col-2">
                                                        <i class="ri-swap-line text-main fs-2"></i>
                                                    </div>
                                                    <div class="col-8">
                                                        <p class="mb-0">Cash Balance</p>
                                                        <p class="mb-0" style="font-size: 10px;">Buy Crypto with your npf Balance</p>
                                                    </div>
                                                    <div class="col-2">
                                                        <i class="ri-arrow-right-line right_arrow_nav text-main"></i>
                                                    </div>
                                                </div>
                                            </a>
                                            <a href="#">
                                                <div class="row align-items-center mb-3 nav_hover p-2">
                                                    <div class="col-2">
                                                        <i class="ri-swap-line text-main fs-2"></i>
                                                    </div>
                                                    <div class="col-8">
                                                        <p class="mb-0">Deposit npf</p>
                                                        <p class="mb-0" style="font-size: 10px;">Add cash</p>
                                                    </div>
                                                    <div class="col-2">
                                                        <i class="ri-arrow-right-line right_arrow_nav text-main"></i>
                                                    </div>
                                                </div>
                                            </a>
                                    </div>
                                </ul>
                            </li>
                            <li class="nav-item mx-1 dropdown">
                                <a class="nav-link text-white nav_margin dropdown-toggle" href="#" role="button"
                                    data-bs-toggle="dropdown" aria-expanded="false">
                                    Markets
                                </a>
                                <ul class="dropdown-menu p-3 grid_nav_transform" style="width: 300px;">
                                    <div>
                                        <a href="#">
                                            <div class="row align-items-center mb-3 nav_hover p-2">
                                                <div class="col-2">
                                                    <i class="fa-solid fa-chart-simple text-main fs-5"></i>
                                                </div>
                                                <div class="col-8">
                                                    <p class="mb-0">Market Overview</p>
                                                    <p class="mb-0" style="font-size: 10px;">Overview of the crypto market
                                                        with real-time prices and key-data</p>
                                                </div>
                                                <div class="col-2">
                                                    <i class="ri-arrow-right-line right_arrow_nav text-main"></i>
                                                </div>
                                            </div>
                                        </a>
                                        <a href="#">
                                            <div class="row align-items-center mb-3 nav_hover p-2">
                                                <div class="col-2">
                                                    <i class="fa-solid fa-chart-line text-main fs-5"></i>
                                                </div>
                                                <div class="col-8">
                                                    <p class="mb-0">Trading Data</p>
                                                    <p class="mb-0" style="font-size: 10px;">View top market movers and
                                                        price performance</p>
                                                </div>
                                                <div class="col-2">
                                                    <i class="ri-arrow-right-line right_arrow_nav text-main"></i>
                                                </div>
                                            </div>
                                        </a>
                                    </div>

                                </ul>
                            </li>

                            <li class="nav-item mx-1 dropdown">
                                <a class="nav-link text-white nav_margin dropdown-toggle" href="#" role="button"
                                    data-bs-toggle="dropdown" aria-expanded="false">
                                    Futures
                                </a>
                                <ul class="dropdown-menu p-3 grid_nav_transform" style="width: 600px;">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <router-link :to="{ name: 'future_trade' }">

                                            <div class="row align-items-center mb-3 nav_hover p-2">
                                                <div class="col-2">
                                                    <i class="fa-solid fa-file-invoice-dollar fs-5 text-main"></i>
                                                </div>
                                                <div class="col-8">
                                                    <p class="mb-0">USD-M Futures</p>
                                                    <p class="mb-0" style="font-size: 10px;">Prepectual or Quarterly
                                                        Contracts settled in USDT or BUSD</p>
                                                </div>
                                                <div class="col-2">
                                                    <i class="ri-arrow-right-line right_arrow_nav text-main"></i>
                                                </div>
                                            </div>
                                            </router-link>
                                            <div class="row align-items-center mb-3 nav_hover p-2">
                                                <div class="col-2">
                                                    <i class="fa-solid fa-file-contract fs-5 text-main"></i>
                                                </div>
                                                <div class="col-8">
                                                    <p class="mb-0">Coin-M Futures</p>
                                                    <p class="mb-0" style="font-size: 10px;">Prepectual or Quarterly
                                                        Contracts settled in Cryptocurrency</p>
                                                </div>
                                                <div class="col-2">
                                                    <i class="ri-arrow-right-line right_arrow_nav text-main"></i>
                                                </div>
                                            </div>
                                            <div class="row align-items-center mb-3 nav_hover p-2">
                                                <div class="col-2">
                                                    <i class="fa-solid fa-scroll text-main fs-5"></i>
                                                </div>
                                                <div class="col-8">
                                                    <p class="mb-0">Options</p>
                                                    <p class="mb-0" style="font-size: 10px;">Buy and sell European-style
                                                        Options</p>
                                                </div>
                                                <div class="col-2">
                                                    <i class="ri-arrow-right-line right_arrow_nav text-main"></i>
                                                </div>
                                            </div>
                                            <div class="row align-items-center mb-3 nav_hover p-2">
                                                <div class="col-2">
                                                    <i class="fa-solid fa-group-arrows-rotate text-main fs-5"></i>
                                                </div>
                                                <div class="col-8">
                                                    <p class="mb-0">Leveraged Token</p>
                                                    <p class="mb-0" style="font-size: 10px;">Enjoy increased leverage
                                                        without risk of liquidation</p>
                                                </div>
                                                <div class="col-2">
                                                    <i class="ri-arrow-right-line right_arrow_nav text-main"></i>
                                                </div>
                                            </div>
                                            <div class="row align-items-center mb-3 nav_hover p-2">
                                                <div class="col-2">
                                                    <i class="fa-solid fa-clipboard-list text-main fs-5"></i>
                                                </div>
                                                <div class="col-8">
                                                    <p class="mb-0">Leaderboard</p>
                                                    <p class="mb-0" style="font-size: 10px;">Exclusive ranking for
                                                        traders,follow top traders strategies</p>
                                                </div>
                                                <div class="col-2">
                                                    <i class="ri-arrow-right-line right_arrow_nav text-main"></i>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="row align-items-center mb-3 nav_hover p-2">
                                                <div class="col-2">
                                                    <i class="fa-solid fa-binoculars text-main fs-5"></i>
                                                </div>
                                                <div class="col-8">
                                                    <p class="mb-0"> Futures Overview</p>
                                                    <p class="mb-0" style="font-size: 10px;">Follow our full range of crypto
                                                        derivative instruments</p>
                                                </div>
                                                <div class="col-2">
                                                    <i class="ri-arrow-right-line right_arrow_nav text-main"></i>
                                                </div>
                                            </div>
                                            <div class="row align-items-center mb-3 nav_hover p-2">
                                                <div class="col-2">
                                                    <i class="fa-solid fa-chart-pie text-main fs-5"></i>
                                                </div>
                                                <div class="col-8">
                                                    <p class="mb-0">Future Markets</p>
                                                    <p class="mb-0" style="font-size: 10px;">View trends and opportunities
                                                        in Future Market before trading</p>
                                                </div>
                                                <div class="col-2">
                                                    <i class="ri-arrow-right-line right_arrow_nav text-main"></i>
                                                </div>
                                            </div>
                                            <div class="row align-items-center mb-3 nav_hover p-2">
                                                <div class="col-2">
                                                    <i class="fa-solid fa-id-badge text-main fs-5"></i>
                                                </div>
                                                <div class="col-8">
                                                    <p class="mb-0">Responsible Trading</p>
                                                    <p class="mb-0" style="font-size: 10px;">Learn how could you practice
                                                        responsible trading with futures.</p>
                                                </div>
                                                <div class="col-2">
                                                    <i class="ri-arrow-right-line right_arrow_nav text-main"></i>
                                                </div>
                                            </div>
                                            <div class="row align-items-center mb-3 nav_hover p-2">
                                                <div class="col-2">
                                                    <i class="fa-solid fa-newspaper fs-5 text-main"></i>
                                                </div>
                                                <div class="col-8">
                                                    <p class="mb-0">Blog</p>
                                                    <p class="mb-0" style="font-size: 10px;">Expand your knowledge and get
                                                        the latest insights in Derivatives Trading</p>
                                                </div>
                                                <div class="col-2">
                                                    <i class="ri-arrow-right-line right_arrow_nav text-main"></i>
                                                </div>
                                            </div>
                                            <div class="row align-items-center mb-3 nav_hover p-2">
                                                <div class="col-2">
                                                    <i class="fa-solid fa-gem text-main fs-5"></i>
                                                </div>
                                                <div class="col-8">
                                                    <p class="mb-0">VIP Portal</p>
                                                    <p class="mb-0" style="font-size: 10px;">VIP Exclusive,Tailor-made
                                                        Institutional Grade Services .</p>
                                                </div>
                                                <div class="col-2">
                                                    <i class="ri-arrow-right-line right_arrow_nav text-main"></i>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </ul>
                            </li>
                            <li class="nav-item mx-1 dropdown">
                                <a class="nav-link text-white nav_margin dropdown-toggle" href="#" role="button"
                                    data-bs-toggle="dropdown" aria-expanded="false">
                                    Earn
                                </a>
                                <ul class="dropdown-menu p-3 grid_nav_transform" style="width: 600px;">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <div class="row align-items-center mb-3 nav_hover p-2">
                                                <div class="col-2">
                                                    <i class="fa-solid fa-piggy-bank fs-5 text-main"></i>
                                                </div>
                                                <div class="col-8">
                                                    <p class="mb-0">npf Earn</p>
                                                    <p class="mb-0" style="font-size: 10px;">One Stop Investment Solution.
                                                    </p>
                                                </div>
                                                <div class="col-2">
                                                    <i class="ri-arrow-right-line right_arrow_nav text-main"></i>
                                                </div>
                                            </div>
                                            <div class="row align-items-center mb-3 nav_hover p-2">
                                                <div class="col-2">
                                                    <i class="fa-solid fa-circle-dollar-to-slot text-main fs-5"></i>
                                                </div>
                                                <div class="col-8">
                                                    <p class="mb-0">Simple Earn</p>
                                                    <p class="mb-0" style="font-size: 10px;">Earn daily rewards on the idle
                                                        tokens.</p>
                                                </div>
                                                <div class="col-2">
                                                    <i class="ri-arrow-right-line right_arrow_nav text-main"></i>
                                                </div>
                                            </div>

                                            <div class="row align-items-center mb-3 nav_hover p-2">
                                                <div class="col-2">
                                                    <i class="fa-solid fa-hammer fs-5 text-main"></i>
                                                </div>
                                                <div class="col-8">
                                                    <p class="mb-0">npf Pool</p>
                                                    <p class="mb-0" style="font-size: 10px;">Mine more rewards for
                                                        connecting to the pool.</p>
                                                </div>
                                                <div class="col-2">
                                                    <i class="ri-arrow-right-line right_arrow_nav text-main"></i>
                                                </div>
                                            </div>
                                            <div class="row align-items-center mb-3 nav_hover p-2">
                                                <div class="col-2">
                                                    <i class="fa-solid fa-arrow-trend-up text-main fs-5"></i>
                                                </div>
                                                <div class="col-8">
                                                    <p class="mb-0">Range Bound</p>
                                                    <p class="mb-0" style="font-size: 10px;">Earn high rewards when the
                                                        market moves sideways</p>
                                                </div>
                                                <div class="col-2">
                                                    <i class="ri-arrow-right-line right_arrow_nav text-main"></i>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="row align-items-center mb-3 nav_hover p-2">
                                                <div class="col-2">
                                                    <i class="fa-solid fa-rocket text-main fs-5"></i>
                                                </div>
                                                <div class="col-8">
                                                    <p class="mb-0">LaunchPad</p>
                                                    <p class="mb-0" style="font-size: 10px;">Token Launch Plateform.</p>
                                                </div>
                                                <div class="col-2">
                                                    <i class="ri-arrow-right-line right_arrow_nav text-main"></i>
                                                </div>
                                            </div>
                                            <div class="row align-items-center mb-3 nav_hover p-2">
                                                <div class="col-2">
                                                    <i class="fa-solid fa-coins fs-5 text-main"></i>
                                                </div>
                                                <div class="col-8">
                                                    <p class="mb-0">Defi Stacking</p>
                                                    <p class="mb-0" style="font-size: 10px;">Easy access to defi
                                                        oppertunites.</p>
                                                </div>
                                                <div class="col-2">
                                                    <i class="ri-arrow-right-line right_arrow_nav text-main"></i>
                                                </div>
                                            </div>
                                            <div class="row align-items-center mb-3 nav_hover p-2">
                                                <div class="col-2">
                                                    <i class="fa-solid fa-group-arrows-rotate fs-5 text-main"></i>
                                                </div>
                                                <div class="col-8">
                                                    <p class="mb-0">Auto-Invest</p>
                                                    <p class="mb-0" style="font-size: 10px;">Accumulate crypto on autopilot.
                                                    </p>
                                                </div>
                                                <div class="col-2">
                                                    <i class="ri-arrow-right-line right_arrow_nav text-main"></i>
                                                </div>
                                            </div>
                                            <div class="row align-items-center mb-3 nav_hover p-2">
                                                <div class="col-2">
                                                    <i class="fa-brands fa-ethereum fs-5 text-main"></i>
                                                </div>
                                                <div class="col-8">
                                                    <p class="mb-0">ETH Stacking</p>
                                                    <p class="mb-0" style="font-size: 10px;">One click stacking,rewards paid
                                                        only.</p>
                                                </div>
                                                <div class="col-2">
                                                    <i class="ri-arrow-right-line right_arrow_nav text-main"></i>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </ul>
                            </li>
                            <li class="nav-item mx-1 dropdown">
                                <a class="nav-link text-white nav_margin dropdown-toggle" href="#" role="button"
                                    data-bs-toggle="dropdown" aria-expanded="false">
                                    Finance
                                </a>
                                <ul class="dropdown-menu p-3 grid_nav_transform" style="width: 300px;">
                                    <div>
                                        <div class="row align-items-center mb-3 nav_hover p-2">
                                            <div class="col-2">
                                                <i class="fa-solid fa-id-card fs-5 text-main"></i>
                                            </div>
                                            <div class="col-8">
                                                <p class="mb-0">npf Card</p>
                                                <p class="mb-0" style="font-size: 10px;">Get upto 8% cashback when you spend
                                                    at 90M merchants worldwide.</p>
                                            </div>
                                            <div class="col-2">
                                                <i class="ri-arrow-right-line right_arrow_nav text-main"></i>
                                            </div>
                                        </div>
                                        <div class="row align-items-center mb-3 nav_hover p-2">
                                            <div class="col-2">
                                                <i class="fa-solid fa-sack-dollar text-main fs-5"></i>
                                            </div>
                                            <div class="col-8">
                                                <p class="mb-0">npf Loans</p>
                                                <p class="mb-0" style="font-size: 10px;">Get an instant loan secured by
                                                    crypto assets.</p>
                                            </div>
                                            <div class="col-2">
                                                <i class="ri-arrow-right-line right_arrow_nav text-main"></i>
                                            </div>
                                        </div>
                                        <div class="row align-items-center mb-3 nav_hover p-2">
                                            <div class="col-2">
                                                <i class="fa-regular fa-credit-card fs-5 text-main"></i>
                                            </div>
                                            <div class="col-8">
                                                <p class="mb-0">npf Pay</p>
                                                <p class="mb-0" style="font-size: 10px;">Send ,receive and spend crypto with
                                                    0 fees.</p>
                                            </div>
                                            <div class="col-2">
                                                <i class="ri-arrow-right-line right_arrow_nav text-main"></i>
                                            </div>
                                        </div>
                                        <div class="row align-items-center mb-3 nav_hover p-2">
                                            <div class="col-2">
                                                <i class="fa-solid fa-gift fs-5 text-main"></i>
                                            </div>
                                            <div class="col-8">
                                                <p class="mb-0">npf Gift Card</p>
                                                <p class="mb-0" style="font-size: 10px;">Customizable crypto gift card.</p>
                                            </div>
                                            <div class="col-2">
                                                <i class="ri-arrow-right-line right_arrow_nav text-main"></i>
                                            </div>
                                        </div>
                                    </div>
                                </ul>
                            </li>
                            <li class="nav-item mx-1">
                                <a class="nav-link text-white" href="#">
                                    NFT
                                </a>
                            </li>
                            <li class="nav-item mx-1 dropdown">
                                <a class="nav-link text-white nav_margin dropdown-toggle" href="#" role="button"
                                    data-bs-toggle="dropdown" aria-expanded="false">
                                    Institutional
                                </a>
                                <ul class="dropdown-menu p-3 grid_nav_transform" style="width: 500px;">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <div class="row align-items-center mb-3 nav_hover p-2">
                                                <div class="col-2">
                                                    <i class="fa-solid fa-house fs-5 text-main"></i>
                                                </div>
                                                <div class="col-8">
                                                    <p class="mb-0">Institutional Home</p>
                                                    <p class="mb-0" style="font-size: 10px;">Premium digital asset solution
                                                        for institutions.</p>
                                                </div>
                                                <div class="col-2">
                                                    <i class="ri-arrow-right-line right_arrow_nav text-main"></i>
                                                </div>
                                            </div>
                                            <div class="row align-items-center mb-3 nav_hover p-2">
                                                <div class="col-2">
                                                    <i class="fa-solid fa-gear fs-5 text-main"></i>
                                                </div>
                                                <div class="col-8">
                                                    <p class="mb-0">Asset Management Solutions</p>
                                                    <p class="mb-0" style="font-size: 10px;">Discover various asset
                                                        manangement solutions.</p>
                                                </div>
                                                <div class="col-2">
                                                    <i class="ri-arrow-right-line right_arrow_nav text-main"></i>
                                                </div>
                                            </div>
                                            <div class="row align-items-center mb-3 nav_hover p-2">
                                                <div class="col-2">
                                                    <i class="fa-solid fa-shield fs-5 text-main"></i>
                                                </div>
                                                <div class="col-8">
                                                    <p class="mb-0">Custody</p>
                                                    <p class="mb-0" style="font-size: 10px;">Secure digital assets with
                                                        leading infrastructure.</p>
                                                </div>
                                                <div class="col-2">
                                                    <i class="ri-arrow-right-line right_arrow_nav text-main"></i>
                                                </div>
                                            </div>

                                        </div>
                                        <div class="col-lg-6">
                                            <div class="row align-items-center mb-3 nav_hover p-2">
                                                <div class="col-2">
                                                    <i class="fa-solid fa-link fs-5 text-main"></i>
                                                </div>
                                                <div class="col-8">
                                                    <p class="mb-0">Link</p>
                                                    <p class="mb-0" style="font-size: 10px;">Connect and grow with npf
                                                        liquidity solutions.</p>
                                                </div>
                                                <div class="col-2">
                                                    <i class="ri-arrow-right-line right_arrow_nav text-main"></i>
                                                </div>
                                            </div>
                                            <div class="row align-items-center mb-3 nav_hover p-2">
                                                <div class="col-2">
                                                    <i class="fa-solid fa-gem fs-5 text-main"></i>
                                                </div>
                                                <div class="col-8">
                                                    <p class="mb-0">VIP Portal</p>
                                                    <p class="mb-0" style="font-size: 10px;">One-stop station made for VIP
                                                        and institutions.</p>
                                                </div>
                                                <div class="col-2">
                                                    <i class="ri-arrow-right-line right_arrow_nav text-main"></i>
                                                </div>
                                            </div>
                                            <div class="row align-items-center mb-3 nav_hover p-2">
                                                <div class="col-2">
                                                    <i class="fa-solid fa-chart-line fs-5 text-main"></i>
                                                </div>
                                                <div class="col-8">
                                                    <p class="mb-0">Historical Markeet Data</p>
                                                    <p class="mb-0" style="font-size: 10px;">Blockchain and crypto
                                                        assest exchange.</p>
                                                </div>
                                                <div class="col-2">
                                                    <i class="ri-arrow-right-line right_arrow_nav text-main"></i>
                                                </div>
                                            </div>

                                        </div>

                                    </div>
                                </ul>
                            </li> -->

                        </ul>
                        <ul class="navbar-nav mb-2 mb-lg-0 align-items-center ">
                           <li class="nav-item mx-1" v-if="auth == true">
                                <a class="nav-link text-white" href="../future_trade"
                                    role="button" aria-controls="offcanvasExample">
                                    Back to Live
                                </a>
                            </li>
                           <!-- <li class="nav-item mx-1" v-if="auth == true">
                                <a class="nav-link text-white" href="/demo/demo_top_up"
                                    role="button" aria-controls="offcanvasExample">
                                    Top Up
                                </a>
                            </li> -->
                           <li class="nav-item mx-1" v-if="auth == true">
                                    <router-link :to="{ name: 'demo_top_up' }"   class="nav-link text-white"  > Top Up
                                </router-link>
                            </li>

                            <li class="nav-item mx-1 dropdown d-none d-sm-block" v-if="auth == true">
                                <a class="nav-link text-white" data-bs-toggle="offcanvas" href="#offcanvasExample2"
                                    role="button" aria-controls="offcanvasExample">
                                    <i class="ri-user-3-fill fs-5"></i>
                                </a>
                            </li>

                        </ul>

                    </div>
                </div>

            </div>
        </nav>
        <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasExample2" aria-labelledby="offcanvasExampleLabel"
            v-if="auth == true">
            <div class="offcanvas-header">
                <button type="button" class="btn-close ms-auto" data-bs-dismiss="offcanvas" aria-label="Close"></button>
            </div>
            <div class="offcanvas-body">
                <a href="#" class="fs-5 nav-link text-white">{{ user.email }}</a>
                <div class="mt-5">
                    <ul class="navbar-nav text-white w-100">

                        <a @click="logout" href="#">
                            <li class="nav-item  nav_item_modal p-3">
                                <i class="fa-solid fa-person-through-window"></i> <span class="ms-3">Log Out</span>
                            </li>
                        </a>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import pagination from "vue-pagination-2";
export default {
    name: "header",
    components: {
        pagination,
    },
    data() {
        return {
            auth: false,
            apiUrl: process.env.mix_api_url,
            user: {},
            logo : '',
            dropToggle: false
        };
    },
    created() {
        var token = localStorage.token;
        if (token != undefined && token != '') {
            this.auth = true;
            this.$emit("auth", this.auth);

        }
        this.userDetails();
        // this.getLogo();
        this.getLiveDeposits();
        this.getEthLiveDeposits();
        this.setTronLiveDeposits();
    },
    methods: {
        dropdowns() {
            this.dropToggle = !this.dropToggle;
        },

        userDetails() {
            axios.post(this.apiUrl + 'api/getUserDetails', {
                token: localStorage.token
            }).then(res => {

                this.user = res.data.user;
                this.$emit("authUser", res.data.user);
                this.balance = res.data.balance;
            }).catch(err => {
                console.log(err);
            });
        },

        getLiveDeposits(){
            console.log("working herrrr");

            axios.get(this.apiUrl+"api/getLiveDeposits",{
                params:{
                    token:localStorage.token
                }
            })
            .then(res=>{
                // console.log("resdddddddddddddddd");
                // console.log(res);
            }).catch(err=>{
                console.log("err");
                console.log(err);
            });
        },
        getEthLiveDeposits(){
            console.log("working herrrr");

            axios.get(this.apiUrl+"api/getEthLiveDeposits",{
                params:{
                    token:localStorage.token
                }
            })
            .then(res=>{
                // console.log("resdddddddddddddddd");
                // console.log(res);
            }).catch(err=>{
                console.log("err");
                console.log(err);
            });
        },
        setTronLiveDeposits(){
            console.log("working herrrr");
            axios.post(this.apiUrl+"api/setTronTransaction",{
                    token:localStorage.token
            })
            .then(res=>{
                // console.log("resdddddddddddddddd");
                // console.log(res);
            }).catch(err=>{
                console.log("err");
                console.log(err);
            });
        },
        getLogo() {
            axios.post(this.apiUrl + 'api/getLogo', {

            }).then(res => {
                console.log('====================================');

                console.log(res.data.logo.logo);
                console.log('====================================');

                this.logo = res.data.logo.logo;
            }).catch(err => {
                console.log(err);
            });
        },
        logout() {
            // axios
            //     .post(this.url + "api/userLogout", {
            //         token: localStorage.token,
            //     })
            //     .then((res) => {
            //         console.log(res);
            //     })
            //     .catch((err) => {
            //         console.log(err);
            //     });
            localStorage.removeItem("token");

            this.$router.push({ name: "index" });
            location.reload();
        },
    }


};
</script>
