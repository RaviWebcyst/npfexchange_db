<template>
<div>
    <section class="layout_padding2 dark_bg ">
            <div class="container mt-5 mb-5">
                <!-- <h1 class="text-light">Start earning today</h1>
            <a href="#" class="btn mt-4 btn-default">Get Started</a> -->
                <div class="row mt-5">
                    <div class="col-lg-3 col-6 my-3">
                        <div class="footer_logo">
                            <img :src="apiUrl + 'logo.png'" alt="footerlogo" width="80">
                        </div>
                        <h4 class="text-yellow">Support Email Address</h4>
                        <h6 class="text-left text-white mt-2">
                            <!-- 123 Second Street Fifth Avenue,<br>Manhattan, New York <br><span class="text-white" style="font-size:14px; color:white !important;"><a
                                    href="tel:+00412584896587" class="text-white">+00 41 258 489 6587</a></span><br> -->
                            <a href="mailto:_mainaccount@npfexchange.com"
                                class="text-white">_mainaccount@npfexchange.com</a>
                        </h6>
                    </div>
                    <div class="col-lg-3 col-6 my-3">
                        <p class="fs-5 fw-bold text-light">Products</p>
                        <a href="">
                            <p class="text-light">Exchange</p>
                        </a>
                        <a href="">
                            <p class="text-light">Academy</p>
                        </a>
                        <!-- <a href="">
                            <p>Binance Live</p>
                        </a> -->
                        <a href="">
                            <p class="text-light">Charity</p>
                        </a>
                    </div>
                    <div class="col-lg-2 col-6 my-3">
                        <p class="fs-5 fw-bold text-light">Service</p>
                        <a href="">
                            <p class="text-light">Downloads</p>
                        </a>
                        <a href="">
                            <p class="text-light">Desktop Application</p>
                        </a>
                        <a href="">
                            <p class="text-light">Buy Crypto</p>
                        </a>
                        <a href="">
                            <p class="text-light">OTC Trading</p>
                        </a>
                    </div>
                    <div class="col-lg-2 col-6 my-3">
                        <p class="fs-5 fw-bold text-light">Support</p>
                        <a href="">
                            <p class="text-light">Fees</p>
                        </a>
                        <!-- <a href="">
                            <p>APIs</p>
                        </a> -->
                        <a href="">
                            <p class="text-light">Support Center</p>
                        </a>
                        <a href="">
                            <p class="text-light">Trading rules</p>
                        </a>
                    </div>
                    <div class="col-lg-2 col-6 my-3">
                        <p class="fs-5 fw-bold text-light">Learn</p>
                        <a href="">
                            <p class="text-light">Learn & Earn</p>
                        </a>
                        <a href="">
                            <p class="text-light">Browser & Crypto Prices</p>
                        </a>
                        <a href="">
                            <p class="text-light">Bitcoin Price</p>
                        </a>
                        <a href="">
                            <p class="text-light">Buy BNB</p>
                        </a>
                    </div>
                    <!-- <div class="col-lg-2 col-6 my-3">
                        <div class="main-heading left_text">
                            <h2 class="fs-5 fw-bold text-light">Contact us</h2>
                        </div>
                        <h6 class="text-left text-white mt-2">123 Second Street Fifth Avenue,Manhattan,<br> New York <br><span class="text-white" style="font-size:14px; color:white !important;"><a
                                    href="tel:+00412584896587" class="text-white">+00 41 258 489 6587</a></span><a
                                href="emailto:info@demo.com" class="text-white">info@demo.com</a></h6>
                    </div> -->
                </div>
            </div>
        </section>
        <!-- footer end -->
        <div class="footer-bottom">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 col-sm-12 col-xs-12 pull-left">
                        <p class="text-center"><strong>NPF EXCHANGE. 2024 All Rights Reserved.</strong></p>
                    </div>
                </div>
            </div>
        </div>
        <!-- Modal Custom Settings-->
        <div class="modal fade right" id="Settingmodal" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog  modal-sm">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Custome Settings</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body custom_setting">
                        <!-- Settings: Color -->
                        <div class="setting-theme pb-3">
                            <h6 class="card-title mb-2 fs-6 d-flex align-items-center"><i
                                    class="icofont-color-bucket fs-4 me-2 text-primary"></i>Template Color Settings
                            </h6>
                            <ul class="list-unstyled row row-cols-3 g-2 choose-skin mb-2 mt-2">
                                <li data-theme="indigo">
                                    <div class="indigo"></div>
                                </li>
                                <li data-theme="tradewind">
                                    <div class="tradewind"></div>
                                </li>
                                <li data-theme="monalisa">
                                    <div class="monalisa"></div>
                                </li>
                                <li data-theme="blue">
                                    <div class="blue"></div>
                                </li>
                                <li data-theme="cyan">
                                    <div class="cyan"></div>
                                </li>
                                <li data-theme="green">
                                    <div class="green"></div>
                                </li>
                                <li data-theme="orange" class="active">
                                    <div class="orange"></div>
                                </li>
                                <li data-theme="blush">
                                    <div class="blush"></div>
                                </li>
                                <li data-theme="red">
                                    <div class="red"></div>
                                </li>
                            </ul>
                        </div>
                        <!-- Settings: Template dynamics -->
                        <div class="dynamic-block py-3">
                            <ul class="list-unstyled choose-skin mb-2 mt-1">
                                <li data-theme="dynamic">
                                    <div class="dynamic"><i class="icofont-paint me-2"></i> Click to Dyanmic Setting
                                    </div>
                                </li>
                            </ul>
                            <div class="dt-setting">
                                <ul class="list-group list-unstyled mt-1">
                                    <li
                                        class="list-group-item d-flex justify-content-between align-items-center py-1 px-2">
                                        <label>Primary Color</label>
                                        <button id="primaryColorPicker"
                                            class="btn bg-primary avatar xs border-0 rounded-0"></button>
                                    </li>
                                    <li
                                        class="list-group-item d-flex justify-content-between align-items-center py-1 px-2">
                                        <label>Secondary Color</label>
                                        <button id="secondaryColorPicker"
                                            class="btn bg-secondary avatar xs border-0 rounded-0"></button>
                                    </li>
                                    <li
                                        class="list-group-item d-flex justify-content-between align-items-center py-1 px-2">
                                        <label class="text-muted">Chart Color 1</label>
                                        <button id="chartColorPicker1"
                                            class="btn chart-color1 avatar xs border-0 rounded-0"></button>
                                    </li>
                                    <li
                                        class="list-group-item d-flex justify-content-between align-items-center py-1 px-2">
                                        <label class="text-muted">Chart Color 2</label>
                                        <button id="chartColorPicker2"
                                            class="btn chart-color2 avatar xs border-0 rounded-0"></button>
                                    </li>
                                    <li
                                        class="list-group-item d-flex justify-content-between align-items-center py-1 px-2">
                                        <label class="text-muted">Chart Color 3</label>
                                        <button id="chartColorPicker3"
                                            class="btn chart-color3 avatar xs border-0 rounded-0"></button>
                                    </li>
                                    <li
                                        class="list-group-item d-flex justify-content-between align-items-center py-1 px-2">
                                        <label class="text-muted">Chart Color 4</label>
                                        <button id="chartColorPicker4"
                                            class="btn chart-color4 avatar xs border-0 rounded-0"></button>
                                    </li>
                                    <li
                                        class="list-group-item d-flex justify-content-between align-items-center py-1 px-2">
                                        <label class="text-muted">Chart Color 5</label>
                                        <button id="chartColorPicker5"
                                            class="btn chart-color5 avatar xs border-0 rounded-0"></button>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <!-- Settings: Font -->
                        <div class="setting-font py-3">
                            <h6 class="card-title mb-2 fs-6 d-flex align-items-center"><i
                                    class="icofont-font fs-4 me-2 text-primary"></i> Font Settings</h6>
                            <ul class="list-group font_setting mt-1">
                                <li class="list-group-item py-1 px-2">
                                    <div class="form-check mb-0">
                                        <input class="form-check-input" type="radio" name="font" id="font-poppins"
                                            value="font-poppins">
                                        <label class="form-check-label" for="font-poppins">
                                            Poppins Google Font
                                        </label>
                                    </div>
                                </li>
                                <li class="list-group-item py-1 px-2">
                                    <div class="form-check mb-0">
                                        <input class="form-check-input" type="radio" name="font" id="font-opensans"
                                            value="font-opensans">
                                        <label class="form-check-label" for="font-opensans">
                                            Open Sans Google Font
                                        </label>
                                    </div>
                                </li>
                                <li class="list-group-item py-1 px-2">
                                    <div class="form-check mb-0">
                                        <input class="form-check-input" type="radio" name="font" id="font-montserrat"
                                            value="font-montserrat">
                                        <label class="form-check-label" for="font-montserrat">
                                            Montserrat Google Font
                                        </label>
                                    </div>
                                </li>
                                <li class="list-group-item py-1 px-2">
                                    <div class="form-check mb-0">
                                        <input class="form-check-input" type="radio" name="font" id="font-Plex"
                                            value="font-Plex" checked="">
                                        <label class="form-check-label" for="font-Plex">
                                            Plex Google Font
                                        </label>
                                    </div>
                                </li>
                            </ul>
                        </div>
                        <!-- Settings: Light/dark -->
                        <div class="setting-mode py-3">
                            <h6 class="card-title mb-2 fs-6 d-flex align-items-center"><i
                                    class="icofont-layout fs-4 me-2 text-primary"></i>Contrast Layout</h6>
                            <ul class="list-group list-unstyled mb-0 mt-1">
                                <li class="list-group-item d-flex align-items-center py-1 px-2">
                                    <div class="form-check form-switch theme-switch mb-0">
                                        <input class="form-check-input" type="checkbox" id="theme-switch">
                                        <label class="form-check-label" for="theme-switch">Enable Dark Mode!</label>
                                    </div>
                                </li>
                                <li class="list-group-item d-flex align-items-center py-1 px-2">
                                    <div class="form-check form-switch theme-high-contrast mb-0">
                                        <input class="form-check-input" type="checkbox" id="theme-high-contrast">
                                        <label class="form-check-label" for="theme-high-contrast">Enable High
                                            Contrast</label>
                                    </div>
                                </li>
                                <li class="list-group-item d-flex align-items-center py-1 px-2">
                                    <div class="form-check form-switch theme-rtl mb-0">
                                        <input class="form-check-input" type="checkbox" id="theme-rtl">
                                        <label class="form-check-label" for="theme-rtl">Enable RTL Mode!</label>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="modal-footer justify-content-start">
                        <button type="button" class="btn btn-white border lift" data-dismiss="modal">Close</button>
                        <button type="button" class="btn btn-primary lift">Save Changes</button>
                    </div>
                </div>
            </div>
        </div>

    </div>


</template>
<script>
export default {
    name: "footer",
    components: {
        
    },
    data() {
        return {
            auth: false,
            apiUrl: process.env.mix_api_url,
            user: {},
            dropToggle: false
        };
    },
};


</script>