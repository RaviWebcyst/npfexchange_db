
// var bodyParser = require('body-parser')

const express = require('express')
const axios = require('axios')
const cron = require('node-cron');


const app = express();
const dotenv = require("dotenv");
const WebSocket = require('ws');
const { Web3 } = require('web3');

const { TronWeb } = require('tronweb');



// Initialize TronWeb instance (you can use any node here, e.g., Shasta or Mainnet)
const tronWeb = new TronWeb({
    fullHost: 'https://api.shasta.trongrid.io', // For Shasta Testnet
});





const Binance = require('node-binance-api');
const binance = new Binance().options({
    APIKEY: 'C2wqJilWgYJDmeeHHMHnFfNycjpQto1BcxMSsANhe1pxRuCeaCjXetsNJySU1wZ0',
    APISECRET: 'J1kKGR0Bqwikgia7uwdkqvvQDcamuBEShH54PooIOiCSnUO7yBCjtSUPthPQ2seS'
});



// const ws = new WebSocket('wss://stream.binance.com:9443/ws/btcusdt@trade'); // Real-time price for BTC/USDT


const { excuteQuery } = require('./lib/db');

const http = require('http').Server(app);

const { ethers } = require("ethers");

dotenv.config({
    path: "./.env",
});

const io = require('socket.io')(http);



// Function to get price data every few seconds
const fetchPrice = async (symbol) => {
    var asset = symbol.toUpperCase();
    var price;
    try {
        // const response = await axios.get(`https://fapi.binance.com/fapi/v1/ticker/price?symbol=${asset}`);
        
        if(asset == "NPFUSDT"){
            var prices = await excuteQuery({ query: 'SELECT price FROM prices  order by id desc limit 1' });
            price = prices[0]['price'];
        }
        else{
            // const response = await axios.get(`https://test.mydreamgrow.in/admin/api/getFuturePrice?symbol=${asset}`);
            const response = await axios.get(`https://muftdeal.com/api/getFuturePrice?symbol=${asset}`);
             price = response.data.price;
        }
        return price;
        console.log(`BTC/USDT Price: ${response.data.price}`);
    } catch (error) {
        console.error('Error fetching price data:', error);
    }
};

// Function to get price data every few seconds
const fetchSpotPrice = async (symbol) => {
    var asset = symbol.toUpperCase();
    var price;
    try {
        // const response = await axios.get(`https://fapi.binance.com/fapi/v1/ticker/price?symbol=${asset}`);
        
        if(asset == "NPFUSDT"){
            var prices = await excuteQuery({ query: 'SELECT price FROM prices  order by id desc limit 1' });
            price = prices[0]['price'];
        }
        else{
            // const response = await axios.get(`https://test.mydreamgrow.in/admin/api/getSpotPrice?symbol=${asset}`);
            const response = await axios.get(`https://muftdeal.com/api/getFuturePrice?symbol=${asset}`);
             price = response.data.price;
        }
        return price;
        console.log(`BTC/USDT Price: ${response.data.price}`);
    } catch (error) {
        console.error('Error fetching price data:', error);
    }
};

//calculate liquidity percentage
const calLiqPer = async (symbol, size, leverage, open_price, current_price) => {
    // var current_price = await fetchPrice(symbol);
    var order_value = (current_price * size) / leverage;   //pnl or margin
    var unrealized_value = (current_price - open_price) * size;
    var percentage = (unrealized_value / order_value) * 100;

    return Number(percentage).toFixed(2);
}



cron.schedule('*/1 * * * * *', async () => {
    console.log('Running a task every second');


    console.log("sdfdsfsdfsdf");

    //for auto close on stop loss and take profit order
    await checkStopLossTakeProfit();

    console.log("sdfsfsdfsfssworkknknsinidffdf");

    //limit order check and close on price match
    var orders = await excuteQuery({ query: 'SELECT * FROM trades where trade_status=0 and order_type="Limit"' });

    console.log(orders.length);

    
    
    if (orders.length > 0) {

        for (var i = 0; i < orders.length; i++) {
            var symbol = orders[i].symbol;
            var order = orders[i];
            symbol = symbol.toLowerCase();

            // var user = await excuteQuery({ query: 'SELECT id,uid  FROM users where id='+order.user_id });


            // let exist = await excuteQuery({ query: 'SELECT count(*) as total FROM trades where order_id=' + order.id });
            // console.log("exist total");
            // console.log(exist[0].total);

            var coin = order.symbol.replace("USDT", "");

            console.log(coin);
            



            // if (coin == "NPF") {
            //     continue;
            // }

            // var wallet_type = await order.type =="Buy" ? 'epin':coin;

            // var order_amount =  await order.type == "Buy" ? order.amount:order.quantity;


            // var balance = await walletBalance(user[0].id,wallet_type);

            // console.log("balance "+balance);
            // console.log("order_amount "+order_amount);



            // if (exist[0].total > 0) {
            //     continue;
            // }

            // if(balance < order_amount){
            //     console.log("insuf ballllllllllllllllll");
            //     continue;
            // }

            // if(final_bal < 0){
            //     continue;
            // }



            // console.log("after continue");

            

            let currentPrice = 0;
            // if (coin == "NPF") {
            //     var price = await excuteQuery({ query: 'SELECT price  FROM prices order by id desc limit 1' });
            //     currentPrice = price[0]['price'];
            // }
            // else {
            //     var price = await binance.prices(order.symbol);
            //     currentPrice = price[order.symbol];
            // }

            console.log("shjererer");
            
            var price = await fetchPrice(order.symbol);
            if(order.trade_type == 'spot'){
                var price = await fetchSpotPrice(order.symbol);
            }

            

            currentPrice  = price;


            console.log("price " + currentPrice);


            // console.log("currentPrice "+currentPrice + " order.price "+order.price);



            const order_excute = await matchOrder(order.price, currentPrice, order.type);




            // var desc = "debit " + order.quantity + " from " + order.type+ " "+ coin;



            if (order_excute == 1) {
                // await excuteQuery({
                //     query: `INSERT INTO trades(price,user_id,quantity,symbol,type,amount,order_type,order_id) values(${order.price}, ${order.user_id}, ${order.quantity}, '${order.symbol}','${order.type}',${order.amount},"Limit",${order.id})`,
                // });

                // if(order.type == "Buy"){                //for buy

                //     // for debit
                //     await excuteQuery({
                //         query: "INSERT INTO wallets(`user_id`,`userId`,`amount`,`from`,`transaction_type`,`wallet_type`,`type`,`description`,`symbol`) values('"+user[0].uid +"', '"+order.user_id+"', '"+order.amount+"', 'trade', 'buy','epin','debit','"+desc+"','"+order.symbol+"')",
                //     });

                //     // for credit  
                //     await excuteQuery({
                //         query: "INSERT INTO wallets(`user_id`,`userId`,`amount`,`from`,`transaction_type`,`wallet_type`,`type`,`description`,`symbol`) values('"+user[0].uid +"', '"+order.user_id+"', '"+order.quantity+"', 'trade', 'buy','"+coin+"','credit','"+desc+"','"+order.symbol+"')",
                //     });
                // }
                // if(order.type == "Sell"){                                       //for sell
                //     // for debit
                //     await excuteQuery({
                //         query: "INSERT INTO wallets(`user_id`,`userId`,`amount`,`from`,`transaction_type`,`wallet_type`,`type`,`description`,`symbol`) values('"+user[0].uid +"', '"+order.user_id+"', '"+order.quantity+"', 'trade', 'sell','"+coin+"','debit','"+desc+"','"+order.symbol+"')",
                //     });

                //     // for credit  
                //     await excuteQuery({
                //         query: "INSERT INTO wallets(`user_id`,`userId`,`amount`,`from`,`transaction_type`,`wallet_type`,`type`,`description`,`symbol`) values('"+user[0].uid +"', '"+order.user_id+"', '"+order.amount+"', 'trade', 'sell','epin','credit','"+desc+"','"+order.symbol+"')",
                //     });

                // }

                // console.log('update trades set trade_status=1  where id=' + order.id);
                

                await excuteQuery({
                    query: 'update trades set trade_status=1  where id=' + order.id,
                });

                if (order.trade_type == 'spot') {
                    await excuteQuery({
                        query: 'update trades set status=1  where id=' + order.id,
                    });
                }

                
            }



            // const ws = new WebSocket(`wss://stream.binance.com:9443/ws/${symbol}@trade`);


            // ws.on('message', async function incoming(data) {
            //     const priceData = JSON.parse(data);
            //     const currentPrice = parseFloat(priceData.p); 
            //     const order_excute =  matchOrder(order.price,currentPrice,order.type);
            //     console.log(order_excute);


            //     // $trade = new trade();
            //     // $trade->price = $price;
            //     // $trade->user_id = $user->id;
            //     // $trade->quantity = $request->quantity;
            //     // $trade->symbol = $symbol;
            //     // $trade->type = "Sell";
            //     // $trade->amount = $final_amount;
            //     // $trade->save();

            //     // $wallet = new wallet();
            //     // $wallet->user_id = $user->uid;
            //     // $wallet->userId = $user->id;
            //     // $wallet->amount = $request->quantity;
            //     // $wallet->from = "trade";
            //     // $wallet->transaction_type = "sell";
            //     // $wallet->wallet_type = $request->coin;
            //     // $wallet->type = "debit";
            //     // $wallet->description = "debit " . $request->quantity . " from sell $request->coin";
            //     // $wallet->symbol = $symbol;
            //     // $wallet->save();

            //     var executed = false;            


            //     if(order_excute == 1){
            //         await excuteQuery({
            //             query: `INSERT INTO trades(price,user_id,quantity,symbol,type,amount,order_type,order_id) values(${order.price}, ${order.user_id}, ${order.quantity}, '${order.symbol}','${order.type}',${order.amount},"Limit",${order.id})`,
            //         });

            //         await excuteQuery({
            //             query: 'update open_orders set status = 1 where id='+order.id,
            //         });

            //         ws.close();
            //         return false;
            //     }

            //     //  console.log(`Real-time price update: $${currentPrice}`);
            // });
            // // ws.close();
            // ws.on("error",() =>{
            //     ws.close();
            // });
        }
    }





    //auto close future market position on 100% 

    let position = await excuteQuery({ query: 'SELECT * FROM trades where trades.status=0 and trades.trade_type="future" and margin_mode="isolated"' });

    if (position.length > 0) {
        for (var i = 0; i < position.length; i++) {
            var symbol = position[i].symbol;
            var size = position[i].quantity;
            var leverage = position[i].leverage;
            var open_price = position[i].price;
            var id = position[i].id;
            var type = position[i].type;

            if (symbol != "NPFUSDT") {
                continue;
            }

            var current_price;
            if (symbol == "NPFUSDT") {
                var npf_price = await excuteQuery({ query: 'SELECT * FROM prices order by id desc limit 1' });
                current_price = npf_price[0]['price'];
            }
            else {
                current_price = await fetchPrice(symbol);
            }

            var per = await calLiqPer(symbol, size, leverage, open_price, current_price);


            var val = -100;
            if (type == "Sell") {
                val = 100;
            }


            if (val >= per) {
                await excuteQuery({
                    query: 'update trades set status = 1,close_price=' + current_price + 'where id=' + id,
                });
            }
        }
    }


});









const closePosition = async (type, position) => {

    var price = type == 'stop_loss'? position.stop_loss: position.take_profit;
    // const currentPrice = await fetchPrice(position.symbol);
    const currentPrice = price;
    let profitLoss = 0;
    if (position.type === 'Buy') {
        profitLoss = (currentPrice - position.price) * position.quantity;
    } else if (position.type === 'Sell') {
        profitLoss = (position.price - currentPrice) * position.quantity;
    }

    
    try {
        var amount = position.amount + profitLoss;
        
        await excuteQuery({
            query: 'update trades set status = 1,close_price=' + currentPrice + ', close_amount=' + amount + ',close_quantity=' + position.quantity + ' where id=' + position.id,
        });


        var user = await excuteQuery({ query: 'SELECT id,uid  FROM users where id=' + position.user_id });

        var type = position.type;
        type  = type.toLowerCase();
        var coin = position.symbol.replace("USDT", "");
        var desc = `Position closed due to ${type === 'stop_loss' ? 'Stop Loss' : 'Take Profit'} at price ${currentPrice}`;


        // for debit
        await excuteQuery({
            query: "INSERT INTO wallets(`user_id`,`userId`,`amount`,`from`,`transaction_type`,`wallet_type`,`type`,`description`,`symbol`,`trade_type`) values('" + user[0].uid + "', '" + position.user_id + "', '" + position.quantity + "', 'future_trade', '" + type + "','" + coin + "','debit','" + desc + "','" + position.symbol + "','" + position.trade_type + "')",
        });

        // for credit  
        await excuteQuery({
            query: "INSERT INTO wallets(`user_id`,`userId`,`amount`,`from`,`transaction_type`,`wallet_type`,`type`,`description`,`symbol`,`trade_type`) values('" + user[0].uid + "', '" + position.user_id + "', '" + amount + "', 'future_trade', '" + coin + "','usd','credit','" + desc + "','" + position.symbol + "','" + position.trade_type + "')",
        });

        console.log(`Position closed with ${type}. Profit/Loss: ${profitLoss}`);
    } catch (error) {
        console.error("Error closing position:", error);
    }


}

const checkStopLossTakeProfit = async () => {
    let positions = await excuteQuery({ query: 'SELECT * FROM trades where trades.status=0 and trades.trade_status=1 and trades.trade_type="future" and (trades.stop_loss IS NOT NULL or trades.take_profit IS NOT NULL)' });
    console.log("positions");
    console.log(positions.length);
    
    if (positions.length > 0) {
        for (var i = 0; i < positions.length; i++) {
            var position = positions[i];
            
            var currentPrice = await fetchPrice(position.symbol);

            console.log(currentPrice);
            

            if (!currentPrice) {
                console.log("Could not fetch the current price.");
                return;
            }

            console.log(`Current Price of ${position.symbol}: $${currentPrice}`);

            if (position.type === 'Buy') {
                // Check Stop Loss for Long Position
                if (position.stop_loss != null && currentPrice <= position.stop_loss) {
                // if (position.stop_loss != null && currentPrice == position.stop_loss) {
                    console.log(`Stop Loss triggered! Selling at $${currentPrice}`);
                    closePosition('stop_loss', position);
                }
                // Check Take Profit for Long Position
                else if (position.take_profit != null && currentPrice >= position.take_profit) {
                // else if (position.take_profit != null && currentPrice == position.take_profit) {
                    console.log(`Take Profit triggered! Selling at $${currentPrice}`);
                    closePosition('take_profit', position);
                }
            } else if (position.type === 'Sell') {
                // Check Stop Loss for Short Position
                if (position.stop_loss != null && currentPrice >= position.stop_loss) {
                // if (position.stop_loss != null && currentPrice == position.stop_loss) {
                    console.log(`Stop Loss triggered! Buying back at $${currentPrice}`);
                    closePosition('stop_loss', position);
                }
                // Check Take Profit for Short Position
                else if (position.take_profit != null && currentPrice <= position.take_profit) {
                // else if (position.take_profit != null && currentPrice == position.take_profit) {
                    console.log(`Take Profit triggered! Buying back at $${currentPrice}`);
                    closePosition('take_profit', position);
                }
            }
        }
    }
}

const walletBalance = async (user_id, wallet_type) => {
    let credit_data = await excuteQuery({ query: `SELECT sum(amount) as total FROM wallets where userId=${user_id} and wallet_type='${wallet_type}' and type='credit'` });
    let debit_data = await excuteQuery({ query: `SELECT sum(amount) as total FROM wallets where userId=${user_id} and wallet_type='${wallet_type}' and type='debit'` });
    var credit = credit_data[0].total;
    var debit = debit_data[0].total;

    var balance = Number(credit - debit);
    return balance;
}


const matchOrder = async (limit_price, mark_price, type) => {
    var order_excute = 0;
    if (type == "Buy" && (mark_price <= limit_price)) {
        order_excute = 1;
    }
    else if (type == "Sell" && (mark_price >= limit_price)) {
        order_excute = 1;
    }
    console.log("order_excute");
    console.log(order_excute);
    

    return order_excute;
}





app.use(express.json());

app.get("/", async (req, res) => {
    res.json("crypto");
});





app.post("/create-account", async (req, res) => {
    try {
        //for ether and bsc
        const account = ethers.Wallet.createRandom();

        // for tron trx 
        const account1 = await tronWeb.createAccount();


        const cryptoWallet = {
            address: account.address,
            privateKey: account.privateKey,
            secretPhrase: account.mnemonic.phrase,
            publicKey: account.publicKey,
            tron_address: account1.address.base58,
            tron_privateKey: account1.privateKey,
            tron_addressHex: account1.address.hex,
        };



        // const cryptoWallet = {
        //     address: "0xDbeaeb8F410C204A838c19d0DE3521CFE9F4615B",
        //     privateKey: "0xcbbbc2d60b2b8db19312d50f18bc8a83e48e72bbb906df579fb07fb7364dc7aa",
        //     secretPhrase: "unknown frog auto release tumble patrol laundry smile knee spider vintage another",
        //     publicKey: "0x02d62c116b2136967b1f2841bbc2a5ba6be726d5e3273c8391981ee738a0968440",
        // };

        res.status(200).json({ data: cryptoWallet });
    } catch (err) {
        // console.log(err, '\n\n');
        // console.log(err.stack);
        res.status(400).json({ error: err.message });
    }
});

app.post("/get-balance", async (req, res) => {
    try {

        const { walletPrivate, walletAddress, contractAddress, netType } = req.body;

        // const walletPrivate = "0xcbbbc2d60b2b8db19312d50f18bc8a83e48e72bbb906df579fb07fb7364dc7aa";
        // const TokenNetwork = await Setting.findOne({
        //     where: {
        //         key: 'token_network',
        //     },
        // });
        // const TokenAddress = await Setting.findOne({
        //     where: {
        //         key: 'token_address',
        //     },
        // });
        // const tokenNet = TokenNetwork.toJSON();
        // const tokenAdd = TokenAddress.toJSON();


        // console.log(tokenNet, '\n\n', tokenNet.value);
        // const rpc_url = (netType === 'livenet') ? process.env.NODE_RCP_URL : (network == 'ETH') ?'https://sepolia.infura.io/v3/' :process.env.NODE_TEST_RCP_URL;

        const rpc_url = (netType === 'livenet') ? process.env.NODE_RCP_URL : process.env.NODE_TEST_RCP_URL;


        const provider = new ethers.JsonRpcProvider(rpc_url);

        const contract = new ethers.Contract(contractAddress, require('./common-abi.json'), provider);

        const wallet = new ethers.Wallet(walletPrivate);
        const connectedWallet = wallet.connect(provider);




        const balance = await provider.getBalance(connectedWallet.address);

        const tokenBalance = await contract.balanceOf(walletAddress);

        const balanceObj = {};

        // if (address?.length > 0) {
        //     address.forEach(async (token) => {
        //         const tempContract = new ethers.Contract(token, require('./common-abi.json'), provider);
        //         const balance = await tempContract.balanceOf("0xDbeaeb8F410C204A838c19d0DE3521CFE9F4615B");
        //         balanceObj[token] = ethers.formatEther(balance) ?? 0;
        //     });
        // }

        // console.log(await contract.name());
        // const tokenName = await contract.name();
        const tokenSymbol = await contract.symbol();
        // const tokenDecimals = await contract.decimals();
        // const tokenAddress = "0xDbeaeb8F410C204A838c19d0DE3521CFE9F4615B";
        // const token = {
        //     name: tokenName,
        //     symbol: tokenSymbol,
        //     decimals: Number(tokenDecimals),
        //     address: tokenAddress,
        //     balance: ethers.formatEther(tokenBalance)
        // }

        const token = {
            symbol: tokenSymbol,
            balance: ethers.formatEther(tokenBalance)
        }

        res.status(200).json({ bnb: ethers.formatEther(balance.toString()), token });
    } catch (err) {
        // console.log(err, '\n\n');
        // console.log(err.stack);
        res.status(400).json({ error: err.message });
    }
});

app.post('/check-token', async (req, res) => {
    try {
        const { address } = req.body;
        if (ethers.isAddress(address)) {

            const provider = new ethers.JsonRpcProvider(process.env.NODE_TEST_RCP_URL);

            const byteCode = await provider.getCode(address);
            if (byteCode === '0x') {
                return res.status(400).json({ error: 'Invalid Address' })
            } else {
                const tokenContract = new ethers.Contract(address, require('./common-abi.json'), provider);
                const tokenName = await tokenContract.name();
                const tokenSymbol = await tokenContract.symbol();
                const tokenDecimals = await tokenContract.decimals();
                const tokenAddress = await tokenContract.getAddress();

                const token = {
                    tokenAddress, tokenDecimals: Number(tokenDecimals), tokenName, tokenSymbol
                }
                return res.status(200).json({ token });
            }
        } else {
            return res.status(400).json({ error: 'Invalid Address' })
        }
    } catch (err) {
        // console.log(err, '\n\n');
        // console.log(err.stack);
        res.status(400).send({ error: err })
    }
});

app.post("/gas_fees", async (req, res) => {
    try {
        const { amount, toAddress, walletPrivate, contractAddress, tokenNet } = req.body;

        var rpc_url = tokenNet === 'livenet' ? process.env.NODE_RCP_URL : process.env.NODE_TEST_RCP_URL;

        console.log(rpc_url);

        const provider = new ethers.JsonRpcProvider(rpc_url);


        // const tokenAddress = contractAddress;
        // const tokenAbi =  require('./common-abi.json');

        // const wallet = new ethers.Wallet(walletPrivate, provider);
        // const tokenContract = new ethers.Contract(tokenAddress, tokenAbi, wallet);


        const sendAmount = ethers.parseEther(amount);

        // const tx = await tokenContract.transfer(toAddress, sendAmount);

        // const gas = await provider.estimateGas(tx);

        const gas = await provider.estimateGas({
            // Wrapped ETH address
            to: toAddress,

            // `function deposit() payable`
            data: "",

            // 1 ether
            value: sendAmount
        });




        res.status(200).json({ data: ethers.formatEther(gas) });
    } catch (e) {
        res.status(400).json({ error: e.shortMessage ?? e.message });
    }
});





app.post("/send-bnb", async (req, res) => {

    try {
        const { amount, toAddress, walletPrivate, tokenNet, contractAddress } = req.body;

        // const provider = new ethers.JsonRpcProvider(tokenNet === 'livenet' ? process.env.NODE_RCP_URL : process.env.NODE_TEST_RCP_URL);

        // const wallet = new ethers.Wallet(walletPrivate, provider);

        //updated code

        //for local
        // const web3 = new Web3(new Web3.providers.HttpProvider('https://data-seed-prebsc-1-s1.binance.org:8545/'));

        var url = tokenNet === 'livenet' ? process.env.NODE_RCP_URL : process.env.NODE_TEST_RCP_URL;

        // const web3 = new Web3(new Web3.providers.HttpProvider('https://bsc-testnet-rpc.publicnode.com/'));
        const web3 = new Web3(new Web3.providers.HttpProvider(url));


        const privateKey = Buffer.from(walletPrivate, 'hex');
        const wallet = web3.eth.accounts.privateKeyToAccount(privateKey);


        var balance = await getUSDTBalance(toAddress);

        //  if(balance < amount || typeof balance == 'object'){
        //  if(balance < amount){
        //     res.status(400).json({"error":"Not Enough balance in user wallet"});
        //     return false;
        //  }


        // const usdtAddress = '0x337610d27c682E347C9cD60BD4b3b107C9d34dDd';

        const usdtAddress = contractAddress;

        const abi = [
            {
                "constant": false,
                "inputs": [
                    {
                        "name": "_to",
                        "type": "address"
                    },
                    {
                        "name": "_value",
                        "type": "uint256"
                    }
                ],
                "name": "transfer",
                "outputs": [
                    {
                        "name": "",
                        "type": "bool"
                    }
                ],
                "type": "function"
            }
        ];


        // Create contract instance
        const contract = new web3.eth.Contract(abi, usdtAddress);

        // Sender's wallet address
        const senderAddress = wallet.address;
        // Receiver's wallet address
        const receiverAddress = toAddress;


        // const tokenAbi =  require('./common-abi.json');

        // const usdtwallet = new ethers.Wallet(walletPrivate, provider);
        // const tokenContract = new ethers.Contract(usdtAddress, tokenAbi, usdtwallet);

        // const balance = await tokenContract.balanceOf(wallet.address);

        // const sendAmount = ethers.parseEther(amount);

        // if(balance < sendAmount){
        //     res.json({"error":"Insufficient usdt balance"});
        //     return false;
        // }



        // Get nonce for the sender's account
        // const nonce = await web3.eth.getTransactionCount(senderAddress, 'latest');

        // var decimals = Number(1000000000000000000);
        var decimals = BigInt(1e18);

        console.log("decimals " + decimals);




        const usdtAmount = BigInt(amount) * decimals;




        const data = contract.methods.transfer(receiverAddress, usdtAmount.toString()).encodeABI();

        var gasLimit = await web3.eth.estimateGas({
            from: receiverAddress,
            to: usdtAddress,
            data: data,
        });

        // nonce: await web3.eth.getTransactionCount(receiverAddress),



        console.log("gasLimit without " + gasLimit);
        // console.log("gasLimit "+ethers.formatEther(gasLimit));

        var gasPrice = await web3.eth.getGasPrice();
        var currentGasPriceGwei = web3.utils.fromWei(gasPrice, 'gwei');

        console.log("gasPrice " + gasPrice);


        console.log("currentGasPriceGwei " + currentGasPriceGwei);
        // console.log("currentGasPriceEther "+ ethers.formatEther(currentGasPriceGwei));


        var priorityGasPriceGwei = Math.ceil(currentGasPriceGwei * 0.6);
        var priorityGasPriceWei = web3.utils.toWei(priorityGasPriceGwei.toString(), 'gwei');

        console.log("priorityGasPriceWei " + priorityGasPriceWei);


        var calAmount = BigInt(gasLimit) * BigInt(priorityGasPriceWei);

        console.log("calAmount " + calAmount);

        const tx = {
            from: senderAddress,
            to: receiverAddress,
            value: calAmount,
            gas: gasLimit,
            gasPrice: await web3.eth.getGasPrice(),
        };

        const signedTx = await web3.eth.accounts.signTransaction(tx, privateKey);
        const receipt = await web3.eth.sendSignedTransaction(signedTx.rawTransaction);
        console.log('Transaction receipt:', receipt);

        res.json("success");
        // res.json(receipt.toString());
        // return;

    } catch (e) {

        if (e.code === 'INSUFFICIENT_FUNDS') {
            return res.status(400).json({ error: 'Insufficient Balance' });
        }
        res.status(400).json({ error: e.shortMessage ?? e.message });
    }
});


app.post("/send_transaction", async (req, res) => {

    const { amount, toAddress, walletPrivate, contractAddress, tokenNet } = req.body;

    // Initialize Web3 for Binance Smart Chain
    // const web3 = new Web3(new Web3.providers.HttpProvider('https://data-seed-prebsc-1-s1.binance.org:8545/'));
    // const web3 = new Web3(new Web3.providers.HttpProvider('https://bsc-testnet-rpc.publicnode.com/'));
    var url = tokenNet === 'livenet' ? process.env.NODE_RCP_URL : process.env.NODE_TEST_RCP_URL;
    const web3 = new Web3(new Web3.providers.HttpProvider(url));

    const usdtAddress = contractAddress;

    const abi = [
        {
            "constant": false,
            "inputs": [
                {
                    "name": "_to",
                    "type": "address"
                },
                {
                    "name": "_value",
                    "type": "uint256"
                }
            ],
            "name": "transfer",
            "outputs": [
                {
                    "name": "",
                    "type": "bool"
                }
            ],
            "type": "function"
        }
    ];

    // Create contract instance
    const contract = new web3.eth.Contract(abi, usdtAddress);
    const privateKey = Buffer.from(walletPrivate, 'hex');


    const senderAddress = web3.eth.accounts.privateKeyToAccount(privateKey).address;


    // Sender's private key (to sign the transaction)

    // const nonce = await web3.eth.getTransactionCount(senderAddress, 'pending');
    try {
        // Get nonce for the sender's account
        // const nonce = await web3.eth.getTransactionCount(senderAddress, 'latest');

        var decimals = BigInt(1e18);

        const usdtAmount = BigInt(amount) * decimals;




        const data = contract.methods.transfer(toAddress, usdtAmount.toString()).encodeABI();

        var gasLimit = await web3.eth.estimateGas({
            from: senderAddress,
            to: usdtAddress,
            data: data
        });


        console.log("gasLimit without " + gasLimit);
        console.log("gasLimit " + ethers.formatEther(gasLimit));

        var gasPrice = await web3.eth.getGasPrice();
        console.log("gasPrice " + gasPrice);

        var currentGasPriceGwei = web3.utils.fromWei(gasPrice, 'gwei');

        console.log("gasPrice " + gasPrice);


        console.log("currentGasPriceGwei " + currentGasPriceGwei);
        // console.log("currentGasPriceEther "+ ethers.formatEther(currentGasPriceGwei));


        var priorityGasPriceGwei = Math.ceil(currentGasPriceGwei * 0.5);
        gasPrice = web3.utils.toWei(priorityGasPriceGwei.toString(), 'gwei');

        const tx = {
            from: senderAddress,
            to: usdtAddress,
            data: data,
            gasPrice: gasPrice,
            gasLimit: web3.utils.toHex(gasLimit)
        };


        const signedTx = await web3.eth.accounts.signTransaction(tx, privateKey);
        const receipt = await web3.eth.sendSignedTransaction(signedTx.rawTransaction);
        console.log('Transaction receipt:', receipt);

        res.json(receipt);
    } catch (error) {
        console.error('Error during transaction:', error);
        res.json(error);
    }

});



app.post("/send-eth", async (req, res) => {

    try {
        const { amount, toAddress, walletPrivate, tokenNet, contractAddress } = req.body;

        var url = tokenNet === 'livenet' ? process.env.NODE_ETH_RCP_URL : process.env.NODE_TEST_ETH_RCP_URL;

        const web3 = new Web3(new Web3.providers.HttpProvider(url));


        const privateKey = Buffer.from(walletPrivate, 'hex');
        const wallet = web3.eth.accounts.privateKeyToAccount(privateKey);
        const usdtAddress = contractAddress;

        const abi = [
            {
                "constant": false,
                "inputs": [
                    {
                        "name": "_to",
                        "type": "address"
                    },
                    {
                        "name": "_value",
                        "type": "uint256"
                    }
                ],
                "name": "transfer",
                "outputs": [
                    {
                        "name": "",
                        "type": "bool"
                    }
                ],
                "type": "function"
            }
        ];


        // Create contract instance
        const contract = new web3.eth.Contract(abi, usdtAddress);

        // Sender's wallet address
        const senderAddress = wallet.address;
        // Receiver's wallet address
        const receiverAddress = toAddress;

        var decimals = BigInt(1e6);

        console.log("decimals " + decimals);

        const usdtAmount = BigInt(amount) * decimals;

        const data = contract.methods.transfer(receiverAddress, usdtAmount.toString()).encodeABI();

        var gasLimit = await web3.eth.estimateGas({
            from: senderAddress,
            to: usdtAddress,
            data: data,
        });

        console.log("gasLimit " + gasLimit);


        // nonce: await web3.eth.getTransactionCount(receiverAddress),



        console.log("gasLimit without " + gasLimit);
        // console.log("gasLimit "+ethers.formatEther(gasLimit));

        var gasPrice = await web3.eth.getGasPrice();
        var currentGasPriceGwei = web3.utils.fromWei(gasPrice, 'gwei');

        console.log("gasPrice " + gasPrice);


        console.log("currentGasPriceGwei " + currentGasPriceGwei);
        // console.log("currentGasPriceEther "+ ethers.formatEther(currentGasPriceGwei));


        var priorityGasPriceGwei = Math.ceil(currentGasPriceGwei * 0.6);
        var priorityGasPriceWei = web3.utils.toWei(priorityGasPriceGwei.toString(), 'gwei');

        console.log("priorityGasPriceWei " + priorityGasPriceWei);


        var calAmount = BigInt(gasLimit) * BigInt(priorityGasPriceWei);

        console.log("calAmount " + calAmount);

        const tx = {
            from: senderAddress,
            to: receiverAddress,
            value: calAmount,
            gas: gasLimit,
            gasPrice: await web3.eth.getGasPrice(),
        };

        const signedTx = await web3.eth.accounts.signTransaction(tx, privateKey);
        const receipt = await web3.eth.sendSignedTransaction(signedTx.rawTransaction);
        console.log('Transaction receipt:', receipt);

        res.json("success");
        // res.json(receipt.toString());
        // return;

    } catch (e) {

        if (e.code === 'INSUFFICIENT_FUNDS') {
            return res.status(400).json({ error: 'Insufficient Balance' });
        }
        res.status(400).json({ error: e.shortMessage ?? e.message });
    }
});


app.post("/send_eth_transaction", async (req, res) => {

    const { amount, toAddress, walletPrivate, contractAddress, tokenNet } = req.body;

    // Initialize Web3 for Binance Smart Chain

    var url = tokenNet === 'livenet' ? process.env.NODE_ETH_RCP_URL : process.env.NODE_TEST_ETH_RCP_URL;
    const web3 = new Web3(new Web3.providers.HttpProvider(url));

    const usdtAddress = contractAddress;

    const abi = [
        {
            "constant": false,
            "inputs": [
                {
                    "name": "_to",
                    "type": "address"
                },
                {
                    "name": "_value",
                    "type": "uint256"
                }
            ],
            "name": "transfer",
            "outputs": [
                {
                    "name": "",
                    "type": "bool"
                }
            ],
            "type": "function"
        }
    ];

    // Create contract instance
    const contract = new web3.eth.Contract(abi, usdtAddress);
    const privateKey = Buffer.from(walletPrivate, 'hex');


    const senderAddress = web3.eth.accounts.privateKeyToAccount(privateKey).address;


    // Sender's private key (to sign the transaction)

    // const nonce = await web3.eth.getTransactionCount(senderAddress, 'pending');
    try {
        // Get nonce for the sender's account
        // const nonce = await web3.eth.getTransactionCount(senderAddress, 'latest');

        var decimals = BigInt(1e6);

        const usdtAmount = BigInt(amount) * decimals;

        const data = contract.methods.transfer(toAddress, usdtAmount.toString()).encodeABI();

        var gasLimit = await web3.eth.estimateGas({
            from: senderAddress,
            to: usdtAddress,
            data: data
        });
        console.log("gasLimit without " + gasLimit);
        console.log("gasLimit " + ethers.formatEther(gasLimit));

        var gasPrice = await web3.eth.getGasPrice();
        console.log("gasPrice " + gasPrice);

        var currentGasPriceGwei = web3.utils.fromWei(gasPrice, 'gwei');

        console.log("gasPrice " + gasPrice);


        console.log("currentGasPriceGwei " + currentGasPriceGwei);
        // console.log("currentGasPriceEther "+ ethers.formatEther(currentGasPriceGwei));


        var priorityGasPriceGwei = Math.ceil(currentGasPriceGwei * 1);
        gasPrice = web3.utils.toWei(priorityGasPriceGwei.toString(), 'gwei');

        const tx = {
            from: senderAddress,
            to: usdtAddress,
            data: data,
            gasPrice: gasPrice,
            gasLimit: web3.utils.toHex(gasLimit)
        };


        const signedTx = await web3.eth.accounts.signTransaction(tx, privateKey);
        const receipt = await web3.eth.sendSignedTransaction(signedTx.rawTransaction);
        console.log('Transaction receipt:', receipt);

        res.json(receipt);
    } catch (error) {
        console.error('Error during transaction:', error);
        res.json(error);
    }

});


app.post("/send-tron", async (req, res) => {

    try {
        const { amount, toAddress, walletPrivate, tokenNet } = req.body;

        var url = tokenNet === 'livenet' ? process.env.NODE_TRX_RCP_URL : process.env.NODE_TEST_TRX_RCP_URL;


        //for shasta trx
        // const tron = new TronWeb({
        //     fullHost: url, 
        //     privateKey: walletPrivate 
        // });


        // Sender's private key
        const privateKey = walletPrivate;

        //for nile trx
        const tron = new TronWeb(url, url, url, walletPrivate);


        // Receiver's address
        // const toAddress = toAddress; 

        // Amount to send (in SUN, 1 TRX = 1,000,000 SUN)
        const final_amount = amount * 1e6;



        const tradeobj = await tron.transactionBuilder.sendTrx(
            toAddress,
            final_amount,
            tron.defaultAddress.base58
        );

        const signedtxn = await tron.trx.sign(tradeobj, privateKey);

        const receipt = await tron.trx.sendRawTransaction(signedtxn);

        console.log('Transaction receipt:', receipt);
        res.json("success");
    } catch (error) {
        console.error('Error while sending TRX:', error);
        res.status(400).json({ error: error.shortMessage ?? error.message });
    }

});

app.post("/send-usdttrc", async (req, res) => {

    try {
        const { amount, toAddress, walletPrivate, tokenNet } = req.body;

        var url = tokenNet === 'livenet' ? process.env.NODE_TRX_RCP_URL : process.env.NODE_TEST_TRX_RCP_URL;



        const tron = new TronWeb({
            fullHost: url,
            privateKey: walletPrivate
        });


        // Sender's private key
        // const privateKey = walletPrivate; 

        // Receiver's address
        // const toAddress = toAddress; 

        // Amount to send (in SUN, 1 TRX = 1,000,000 SUN)
        const usdtContractAddress = 'TXLAQ63Xg1NAzckPwKHvzw7CSEmLMEqcdj'; // USDT TRC20 contract address
        const decimals = 6; // USDT has 6 decimal places

        // Create a contract instance for USDT
        const usdtContract = await tron.contract().at(usdtContractAddress);

        // Prepare the amount in the smallest unit
        const sendAmount = amount * Math.pow(10, decimals);

        // Send the TRC20 token
        const tx = await usdtContract.transfer(toAddress, sendAmount).send();

        console.log('Transaction successful:', tx);

        // Wait for the transaction to be confirmed
        const transactionInfo = await tron.trx.getTransaction(tx);

        // Display transaction info
        console.log(`Transaction Info: ${JSON.stringify(transactionInfo)}`);

        // Calculate energy used
        const energyUsed = transactionInfo.energy_used; // Energy used in the transaction

        // Get the current energy price
        const currentEnergyPrice = await tron.trx.getCurrentBlock().then(block => block.energy_fee); // Current energy fee
        console.log(`Current energy price: ${currentEnergyPrice}`);

        // Calculate total cost in TRX (1 TRX = 1,000,000 Sun)
        const totalCostInTRX = (energyUsed * currentEnergyPrice) / 1000000; // Convert Sun to TRX

        console.log(`Total cost in TRX: ${totalCostInTRX}`);
        res.json('success');
    } catch (error) {
        console.error('Error while sending TRX:', error);
        res.status(400).json({ error: error.shortMessage ?? error.message });
    }

});




app.post("/transfer-bnb", async (req, res) => {
    try {
        const { amount, toAddress, walletPrivate, tokenNet } = req.body;



        const provider = new ethers.JsonRpcProvider(tokenNet === 'livenet' ? process.env.NODE_RCP_URL : process.env.NODE_TEST_RCP_URL);

        const wallet = new ethers.Wallet(walletPrivate, provider);

        const balance = await provider.getBalance(wallet.address);

        const parsedAmount = ethers.parseEther(amount);
        const txReq = {
            to: toAddress,
            value: ethers.parseEther(amount),
        };

        const transaction = await wallet.sendTransaction(txReq);
        const gas = await provider.estimateGas(transaction);
        if ((parsedAmount + gas) > balance) {
            return res.status(400).json({ error: 'Insufficient Balance' });
        }
        const fees = parsedAmount + gas;
        const tx = await transaction.wait();
        // if (tx.status === 1) {
        res.status(200).json({ data: tx, amount, toAddress, contractAddress: 'binance', fees: ethers.formatEther(fees) });
        // }
    } catch (e) {
        // console.log(err, '\n\n');
        // console.log(err.stack);
        // console.log(e.code)
        if (e.code === 'INSUFFICIENT_FUNDS') {
            return res.status(400).json({ error: 'Insufficient Balance' });
        }
        res.status(400).json({ error: e.shortMessage ?? e.message });
    }
});


app.post("/transfer-token", async (req, res) => {
    try {
        const { amount, toAddress, walletPrivate, contractAddress, tokenNet } = req.body;



        const provider = new ethers.JsonRpcProvider(tokenNet === 'livenet' ? process.env.NODE_RCP_URL : process.env.NODE_TEST_RCP_URL);

        const tokenAddress = contractAddress;
        const tokenAbi = require('./common-abi.json');

        const wallet = new ethers.Wallet(walletPrivate, provider);
        const tokenContract = new ethers.Contract(tokenAddress, tokenAbi, wallet);

        const balance = await tokenContract.balanceOf(wallet.address);
        const binanceBalance = await provider.getBalance(wallet.address);

        console.log("binanceBalance " + binanceBalance);




        const sendAmount = ethers.parseEther(amount);

        if (sendAmount > balance) {
            return res.status(400).send({ error: "Insuficiant Token Balance" })
        }



        const tx = await tokenContract.transfer(toAddress, sendAmount);



        const gas = await provider.estimateGas(tx);

        if (gas > binanceBalance) {
            return res.status(400).send({ error: "Insuficiant BNB Balance" })
        }

        const transaction = await tx.wait();


        res.status(200).json({ data: transaction, amount, toAddress, contractAddress, fees: ethers.formatEther(gas) });
    } catch (e) {
        // console.log(e, '\n\n');
        // console.log(err.stack);
        if (e.code === 'INSUFFICIENT_FUNDS') {
            return res.status(400).json({ error: 'Insufficient BNB Balance' });
        }
        res.status(400).json({ error: e.shortMessage ?? e.message });
    }
});






const getUSDTBalance = async (address) => {
    const usdtABI = [
        {
            "constant": true,
            "inputs": [{ "name": "_owner", "type": "address" }],
            "name": "balanceOf",
            "outputs": [{ "name": "balance", "type": "uint256" }],
            "type": "function"
        },
        {
            "constant": true,
            "inputs": [],
            "name": "decimals",
            "outputs": [{ "name": "", "type": "uint8" }],
            "type": "function"
        }
    ];

    const web3 = new Web3(new Web3.providers.HttpProvider('https://bsc-testnet-rpc.publicnode.com/'));


    try {
        // Create contract instance
        const contract = new web3.eth.Contract(usdtABI, "0x337610d27c682E347C9cD60BD4b3b107C9d34dDd");

        // Get USDT balance (balanceOf function)
        const balance = await contract.methods.balanceOf(address).call();

        // Get token decimals
        const decimals = await contract.methods.decimals().call();

        const usdtBalance = BigInt(balance) / BigInt(1000000000000000000);

        return usdtBalance;

        console.log(`USDT Balance: ${usdtBalance}`);
    } catch (error) {

        return error;
        console.error('Error fetching USDT balance:', error);
    }
};




http.listen(4000, () => {
    console.log(`Server listening on port 4000`);
});

