<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class bonus_income extends Model
{
    protected $guarded = [];
}
