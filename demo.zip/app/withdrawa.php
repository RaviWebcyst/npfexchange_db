<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class withdrawa extends Model
{
    //
}
