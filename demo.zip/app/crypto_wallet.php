<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class crypto_wallet extends Model
{
    protected $guarded = [];
}
