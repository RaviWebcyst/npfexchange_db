<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class callback extends Model
{
    protected $guarded = [];
}
