<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class leverage extends Model
{
    protected $guarded = [];
}
