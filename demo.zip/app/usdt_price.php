<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class usdt_price extends Model
{
    protected $guarded = [];
}
