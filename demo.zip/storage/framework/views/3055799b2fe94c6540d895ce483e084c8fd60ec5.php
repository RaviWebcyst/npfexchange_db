<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <section class="content">
        <div class="container-fluid">
            <?php if(session('success')): ?>
                <div class="alert alert-success"><?php echo e(session('success')); ?></div>
            <?php endif; ?>
            <?php if(session('error')): ?>
                <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
            <?php endif; ?>
            <div class="card">
                <div class="card-header">
                  <h3 class="card-title ">Pending Payments</h3>
                  <div class="card-tools d-flex mt-1">
                    <form class="form-inline ml-3" action="" method="get">
                        <div class="input-group input-group-sm">
                            <select name="type" id="" class="form-control form-select" required>
                                <option value="" disabled selected>Search Type</option>

                                <option value="name" <?php echo e(Request()->type == 'name' ? 'selected' : ''); ?>>Name </option>
                                <option value="uid" <?php echo e(Request()->type == 'uid' ? 'selected' : ''); ?>>  User Id</option>
                                <option value="address" <?php echo e(Request()->type == 'address' ? 'selected' : ''); ?>>Address </option>
                                <option value="hash" <?php echo e(Request()->type == 'hash' ? 'selected' : ''); ?>>	Transaction Hash </option>
                             </select>
                        </div>


                        <div class="input-group input-group-sm  mt-3 mt-sm-0   ml-lg-3">
                            <input class="form-control form-control-navbar" type="search" placeholder="Search"
                                name="search" value="<?php echo e(Request()->search); ?>" required>
                            <div class="input-group-append">
                                <button class="btn btn-success" type="submit">
                                    <i class="fas fa-search"></i>
                                </button>
                                <a class="btn btn-danger ml-3" href="<?php echo e(route('admin.pending_deposits')); ?>">Reset
                                </a>
                            </div>
                        </div>
                      </form>
                </div>
                </div>
                <!-- /.card-header -->
                <div class="card-body p-0">
                <div class="table-responsive">
                  <table class="table ">
                    <thead>
                        <tr>
                            <th>Sr. No.</th>
                            <th>User Name</th>
                             
                             <th>Amount</th>
                             <th>Transaction Hash</th>
                             <th>Address</th>
                             <th>Remarks</th>
                            
                            <th>Date</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(count($payments) > 0): ?>
                        <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->index + 1); ?></td>
                            <td> <?php echo e($payment->name ? $payment->name : ''); ?>(<?php echo e($payment->uid ? $payment->uid : ''); ?>)</td>
                            
                            <td>$<?php echo e($payment->amount); ?></td>
                            <td><?php echo e($payment->hash); ?></td>
                            <td><?php echo e($payment->address); ?></td>
                            <td><?php echo e($payment->remarks); ?></td>
                            
                            <td><?php echo e($payment->created_at); ?></td>
                            <td class="d-flex">
                               <form method="POST" class="my-0" action="<?php echo e(route('admin.accept_deposit')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden"  name="id" value="<?php echo e($payment->id); ?>">
                                <button type="submit" class="btn btn-sm btn-primary " onclick="return confirm('Are You Sure Want to Confirm!')">
                                    Confirm
                                </button>
                               </form>
                                <a href="#" class="btn btn-sm btn-danger ml-2 "  data-toggle="modal" data-target="#exampleModal" onclick="rejectRequest(<?php echo e($payment->id); ?>)">
                                    Reject
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                        <tr>
                            <td colspan="7" class="text-center py-3 h5"><b>Data Not Found</b></td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                  </table>
                </div>

                </div>
              </div>
        </div>
    </section>
</div>
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Reject Payment</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>

        </div>
        <div class="modal-body">
            <form  method="POST" action="<?php echo e(route('admin.reject_deposit')); ?>">
                <?php echo csrf_field(); ?>
                <input type="hidden" id="payment_id" name="id" >
                <div class="form-group">
                    <label>Enter Reason</label>
                    <textarea class="form-control" name="remarks" rows="3" placeholder="Enter Reject Reason" required></textarea>
                </div>
                <button type="submit" class="btn btn-primary my-2">Submit</button>

            </form>
        </div>

      </div>
    </div>
  </div>
<script>
    function rejectRequest(id){
        document.getElementById('payment_id').value = id;
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/npfexcha/public_html/demo/resources/views/admin/pending_deposits.blade.php ENDPATH**/ ?>