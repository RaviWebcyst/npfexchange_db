<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <section class="content">
        <div class="container-fluid">
            <?php if(session('success')): ?>
                <div class="alert alert-success"><?php echo e(session('success')); ?></div>
            <?php endif; ?>
            <?php if(session('error')): ?>
                <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
            <?php endif; ?>
            <div class="card">
                <div class="card-header">
                  <h3 class="card-title ">Future Trading History</h3>
                  <div class="card-tools d-sm-flex mt-1 d-block">
                    <form class="form-inline ml-0 ml-sm-3 mt-4" action="" method="get" id="select_type">
                        <div class="input-group input-group-sm">
                            <select name="status"  class="form-control form-select"  onchange="$('#select_type').submit();">
                                <option value="" disabled selected>Select Order Type</option>
                                <option value="" <?php echo e(Request()->status == null ? 'selected':''); ?>>All Orders </option>
                                <option value="0" <?php echo e(Request()->status == '0' ? 'selected':''); ?>>Open Orders </option>
                                <option value="1" <?php echo e(Request()->status == '1' ? 'selected':''); ?>>Close Orders </option>
                            </select>
                        </div>
                        <div class="input-group input-group-sm  mt-3 mt-sm-0   ml-lg-3">
                            <input class="form-control form-control-navbar" type="date" placeholder="Search" name="date" value="<?php echo e(Request()->date); ?>" onchange="$('#select_type').submit();">
                        </div>
                      
                    

                    
                        <div class="input-group input-group-sm ml-0 ml-sm-3 mt-3 mt-sm-0 ">
                            <select name="type" id="" class="form-control form-select" >
                                <option value="" disabled selected>Search Type</option>
                                <option value="name" <?php echo e(Request()->type == 'name' ? 'selected' : ''); ?>> Name</option>
                                <option value="uid" <?php echo e(Request()->type == 'uid' ? 'selected' : ''); ?>>  User Id</option>
                                <option value="symbol" <?php echo e(Request()->type == 'symbol' ? 'selected' : ''); ?>>Symbol </option>
                                
                             </select>
                        </div>

                        <div class="mt-3 mt-sm-2 ml-lg-3 ">
                            <input class="form-control form-control-sm" type="search" placeholder="Search" name="search" value="<?php echo e(Request()->search); ?>" >
                        </div>
                        <div class="mt-3 mt-sm-2 ml-3 ml-sm-3 ">
                            <button class="btn btn-success btn-sm" type="submit"> Search </button>
                            <a class="btn btn-danger ml-3 btn-sm" href="<?php echo e(route('admin.future_trading_history')); ?>">Reset </a>
                        </div>
                    </form>
                </div>
                </div>
                <!-- /.card-header -->
                <div class="card-body p-0">
                  <div class="table-responsive">
                  <table class="table ">
                    <thead>
                      <tr>
                        <th >#</th>
                        <th>User</th>
                        <th>Symbol</th>
                        <th>Type</th>
                        <th>Open Price</th>
                        <th>Amount(USDT)</th>
                        <th>Close Price</th>
                        <th>Leverage</th>
                        <th style="min-width:120px;">Date</th>
                      </tr>
                    </thead>
                    <tbody>

                        <?php if(count($future_history) > 0): ?>
                        <?php $__currentLoopData = $future_history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$trade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($future_history->firstItem()+$key); ?></td>

                            <td><?php echo e($trade->name); ?>(<?php echo e($trade->uid); ?>)</td>

                            <td><?php echo e($trade->symbol); ?></td>
                            <td><?php echo e($trade->type); ?></td>
                            <td><?php echo e($trade->price); ?></td>
                            <td>$<?php echo e($trade->amount); ?></td>
                            <td><?php echo e($trade->close_price); ?></td>
                            <td><?php echo e($trade->leverage); ?></td>
                            
                            <td><?php echo e($trade->created_at); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                        <tr>
                            <td colspan="9" class="text-center py-3 h5"><b>Data Not Found</b></td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                  </table>
                  <?php echo e($future_history->links()); ?>

                  </div>
                </div>
              </div>
        </div>
    </section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/npfexcha/public_html/demo/resources/views/admin/future_history.blade.php ENDPATH**/ ?>