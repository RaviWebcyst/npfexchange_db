<?php
$data = App\setting::first();

?>

<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>   <?php echo e(isset($data->title) ? $data->title : ' Admin Dashboard'); ?></title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/fontawesome-free/css/all.min.css')); ?>">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Tempusdominus Bbootstrap 4 -->
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css')); ?>">
  <!-- iCheck -->
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/icheck-bootstrap/icheck-bootstrap.min.css')); ?>">
  <!-- JQVMap -->
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/jqvmap/jqvmap.min.css')); ?>">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo e(asset('admin/dist/css/adminlte.min.css')); ?>">
  <!-- overlayScrollbars -->
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/overlayScrollbars/css/OverlayScrollbars.min.css')); ?>">
  <!-- Daterange picker -->
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/daterangepicker/daterangepicker.css')); ?>">
  <!-- summernote -->
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/summernote/summernote-bs4.css')); ?>">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  
</head>
<body class="hold-transition sidebar-mini layout-fixed " id="side">
<div class="wrapper">

  <!-- Navbar -->
  <nav class="main-header navbar navbar-expand navbar-white navbar-light fixed-top mb-5">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#"><i class="fas fa-bars"></i></a>
      </li>
    </ul>

    <ul class="navbar-nav ml-auto">
      <li class="nav-item ">
        <a class="nav-link" href="<?php echo e(route('admin.logout')); ?>"
        onclick="event.preventDefault();
                      document.getElementById('logout-form').submit();">
          Logout
        </a>
        <form id="logout-form" action="<?php echo e(route('admin.logout')); ?>" method="POST" style="display: none;">
            <?php echo csrf_field(); ?>
        </form>
  </nav>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="#" class="brand-link">
      <img src="<?php echo e(asset('admin/dist/img/AdminLTELogo.png')); ?>" alt="AdminLTE Logo" class="brand-image img-circle elevation-3"
           style="opacity: .8">
      <span class="brand-text font-weight-light">Admin Panel</span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user panel (optional) -->
      <div class="user-panel mt-3 pb-2 mb-2 d-flex">
        <div class="image mt-2">
          <img src="<?php echo e(isset($data->logo) ? asset('uploads/logo/' . $data->logo) : asset('logo.png')); ?>" class="img-circle elevation-2 mt-lg-0 " alt="User Image">
        </div>
        <div class="info">
          <a href="#" class="d-block my-auto"><?php echo e(Auth::user()->name); ?></a>
        </div>
      </div>

      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          <li class="nav-item ">
            <a href="<?php echo e(route('admin.home')); ?>" class="nav-link <?php echo e(request()->is('admin/home') ? 'active' : ''); ?>">
              <i class="nav-icon fas fa-tachometer-alt"></i>
              <p>
                Dashboard
              </p>
            </a>
          </li>
          <li class="nav-item has-treeview">
            <a href="#" class="nav-link <?php echo e(request()->is('admin/users') || request()->is('admin/activeUsers') ? 'active' : ''); ?>">
              <i class="nav-icon fas fa-users"></i>
              <p>
                  Users
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview" style="display: none;">
              <li class="nav-item">
                <a href="<?php echo e(route('admin.users')); ?>" class="nav-link <?php echo e(request()->is('admin/users') ? 'active' : ''); ?>">
                  <i class="far fa-circle nav-icon"></i>
                  <p>All Users</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo e(route('admin.activeUsers')); ?>" class="nav-link <?php echo e(request()->is('admin/activeUsers') ? 'active' : ''); ?>">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Active Users</p>
                </a>
              </li>
            </ul>
          </li>
            
            <li class="nav-item has-treeview">
            <a href="#" class="nav-link <?php echo e(request()->is('admin/rejected_deposits') || request()->is('admin/pending_deposits') ||  request()->is('admin/completed_deposits')  ? 'active' : ''); ?>">
              
              <i class="fas fa-dollar-sign nav-icon"></i>
              <p> Deposit Payments <i class="fas fa-angle-left right"></i> </p>
            </a>
            <ul class="nav nav-treeview" style="display: none;">
              <li class="nav-item">
                <a href="<?php echo e(route('admin.pending_deposits')); ?>" class="nav-link <?php echo e(request()->is('admin/pending_deposits') ? 'active' : ''); ?>">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Pending Payments</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo e(route('admin.completed_deposits')); ?>" class="nav-link  <?php echo e(request()->is('admin/completed_deposits') ? 'active' : ''); ?>">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Completed Payments</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo e(route('admin.rejected_deposits')); ?>" class="nav-link  <?php echo e(request()->is('admin/rejected_deposits') ? 'active' : ''); ?>">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Rejected Payments</p>
                </a>
              </li>
            </ul>
          </li>
          <li class="nav-item ">
            <a href="<?php echo e(route('admin.transactions')); ?>" class="nav-link <?php echo e(request()->is('admin/transactions') ? 'active' : ''); ?>">
              <i class="nav-icon fas fa-wallet"></i>
              <p>
                Transactions
              </p>
            </a>
          </li>
          
          <li class="nav-item ">
            <a href="<?php echo e(route('admin.trades')); ?>" class="nav-link <?php echo e(request()->is('admin/all_trades') ? 'active' : ''); ?>">
              <i class="nav-icon fas fa-chart-line"></i>
              <p>
                Trades
              </p>
            </a>
          </li>

          <li class="nav-item has-treeview">
            <a href="#" class="nav-link <?php echo e(request()->is('admin/spot_trading_history') || request()->is('admin/future_trading_history') ? 'active' : ''); ?>">
              
              <i class="fas fa-exchange-alt nav-icon"></i>
              <p>
                 Trade History
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview" style="display: none;">
                <li class="nav-item">
                    <a href="<?php echo e(route('admin.spot_trading_history', ['status' => 0])); ?>" class="nav-link <?php echo e(request()->is('admin/spot_trading_history') ? 'active' : ''); ?>">
                      <i class="far fa-circle nav-icon"></i>
                      <p>Spot Trading</p>
                    </a>
                  </li>
              <li class="nav-item">
                <a href="<?php echo e(route('admin.future_trading_history', ['status' => 0])); ?>" class="nav-link <?php echo e(request()->is('admin/future_trading_history') ? 'active' : ''); ?>">
                    <i class="far fa-circle nav-icon"></i>
                  <p>Future Trading</p>
                </a>
              </li>


            </ul>
          </li>




          <li class="nav-item ">
            <a href="<?php echo e(route('admin.coins')); ?>" class="nav-link <?php echo e(request()->is('admin/coins') ? 'active' : ''); ?>">
              <i class="nav-icon fas fa-coins"></i>
              <p>
                Coins
              </p>
            </a>
          </li>
          <li class="nav-item ">
            <a href="<?php echo e(route('admin.assets')); ?>" class="nav-link <?php echo e(request()->is('admin/assets') ? 'active' : ''); ?>">
              
              <i class="fas fa-th-list nav-icon"></i>
              <p>
                Assets
              </p>
            </a>
          </li>
          <li class="nav-item ">
            <a href="<?php echo e(route('admin.posts')); ?>" class="nav-link <?php echo e(request()->is('admin/posts') ? 'active' : ''); ?>">
              <i class="nav-icon fas fa-newspaper"></i>
              <p>
                Posts
              </p>
            </a>
          </li>

          <li class="nav-item has-treeview">
            <a href="#" class="nav-link <?php echo e(request()->is('admin/pending_payments') || request()->is('admin/completed_payments') || request()->is('admin/rejected_payments') ? 'active' : ''); ?>">
              
              <i class="fas fa-exchange-alt nav-icon"></i>
              <p>
                 P2P Deposits
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview" style="display: none;">
              <li class="nav-item">
                <a href="<?php echo e(route('admin.pending_payments')); ?>" class="nav-link <?php echo e(request()->is('admin/pending_payments') ? 'active' : ''); ?>">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Pending Payments</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo e(route('admin.completed_payments')); ?>" class="nav-link <?php echo e(request()->is('admin/completed_payments') ? 'active' : ''); ?>">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Completed Payments</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo e(route('admin.rejected_payments')); ?>" class="nav-link <?php echo e(request()->is('admin/rejected_payments') ? 'active' : ''); ?>">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Rejected Payments</p>
                </a>
              </li>
            </ul>
          </li>
          <li class="nav-item has-treeview">
            <a href="#" class="nav-link <?php echo e(request()->is('admin/pending_withdraw') || request()->is('admin/completed_withdraw') || request()->is('admin/rejected_withdraw') ? "active" : ''); ?>">
              <i class="nav-icon fas fa-wallet"></i>
              <p>
                  Withdraw
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview" style="display: none;">
              <li class="nav-item">
                <a href="<?php echo e(route('admin.pending_withdraw')); ?>" class="nav-link <?php echo e(request()->is('admin/pending_withdraw') ?'active' : ''); ?>">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Pending Withdraw</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo e(route('admin.completed_withdraw')); ?>" class="nav-link <?php echo e(request()->is('admin/completed_withdraw') ? 'active' : ''); ?>">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Completed Withdraw</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo e(route('admin.rejected_withdraw')); ?>" class="nav-link <?php echo e(request()->is('admin/rejected_withdraw') ? 'active' : ''); ?>">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Rejected Withdraw</p>
                </a>
              </li>
            </ul>
          </li>

          <li class="nav-item has-treeview">
            <a href="#" class="nav-link <?php echo e(request()->is('admin/price') || request()->is('admin/website_setting') || request()->is('admin/usdt_price') || request()->is('admin/add_upi') ? 'active' : ''); ?>">
              <i class="nav-icon fas fa-cog"></i>
              <p>
                  Settings
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview" style="display: none;">
              <li class="nav-item ">
                <a href="<?php echo e(route('admin.price')); ?>" class="nav-link <?php echo e(request()->is('admin/price') ? 'active' : ''); ?>">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Price Setting(NPF)</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo e(route('admin.usdt_price')); ?>" class="nav-link <?php echo e(request()->is('admin/usdt_price') ? 'active' : ''); ?>">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Price Setting(USDT)</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo e(route('admin.add_upi')); ?>" class="nav-link <?php echo e(request()->is('admin/add_upi') ? 'active' : ''); ?>">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Address Setting</p>
                </a>
              </li>

              <li class="nav-item">
                <a href="<?php echo e(route('admin.website_setting')); ?>" class="nav-link <?php echo e(request()->is('admin/website_setting') ? 'active' : ''); ?>">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Website Setting</p>
                </a>
              </li>
            </ul>
          </li>
          <li class="nav-item ">
            <a href="<?php echo e(route('admin.logout')); ?>" class="nav-link <?php echo e(request()->is('admin/logout') ? 'active' : ''); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
              <i class="fas fa-sign-out-alt nav-icon"></i>
              <p> Logout </p>
            </a>
            <form id="logout-form" action="<?php echo e(route('admin.logout')); ?>" method="POST" style="display: none;">
                <?php echo csrf_field(); ?>
            </form>
          </li>
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>
        <main class="py-4 mt-5">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
    <!-- jQuery -->
<script src="<?php echo e(asset('admin/plugins/jquery/jquery.min.js')); ?>"></script>
<!-- jQuery UI 1.11.4 -->
<script src="<?php echo e(asset('admin/plugins/jquery-ui/jquery-ui.min.js')); ?>"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
  $.widget.bridge('uibutton', $.ui.button)
</script>
<!-- Bootstrap 4 -->
<script src="<?php echo e(asset('admin/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<!-- ChartJS -->
<script src="<?php echo e(asset('admin/plugins/chart.js/Chart.min.js')); ?>"></script>
<!-- Sparkline -->
<script src="<?php echo e(asset('admin/plugins/sparklines/sparkline.js')); ?>"></script>
<!-- JQVMap -->
<script src="<?php echo e(asset('admin/plugins/jqvmap/jquery.vmap.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/jqvmap/maps/jquery.vmap.usa.js')); ?>"></script>
<!-- jQuery Knob Chart -->
<script src="<?php echo e(asset('admin/plugins/jquery-knob/jquery.knob.min.js')); ?>"></script>
<!-- daterangepicker -->
<script src="<?php echo e(asset('admin/plugins/moment/moment.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/daterangepicker/daterangepicker.js')); ?>"></script>
<!-- Tempusdominus Bootstrap 4 -->
<script src="<?php echo e(asset('admin/plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js')); ?>"></script>
<!-- Summernote -->
<script src="<?php echo e(asset('admin/plugins/summernote/summernote-bs4.min.js')); ?>"></script>
<!-- overlayScrollbars -->
<script src="<?php echo e(asset('admin/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js')); ?>"></script>
<!-- AdminLTE App -->
<script src="<?php echo e(asset('admin/dist/js/adminlte.js')); ?>"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="<?php echo e(asset('admin/dist/js/pages/dashboard.js')); ?>"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo e(asset('admin/dist/js/demo.js')); ?>"></script>

<script>



//watch window resize
$(window).on('resize', function() {
  if ($(this).width() > 950) {
    $('#side').addClass('sidebar-open').removeClass('sidebar-collapse');
  }
  else{
    $('#side').addClass('sidebar-collapse').removeClass('sidebar-open');
  }
});

$(window).on('load', function() {
  if ($(this).width() > 950) {
    $('#side').addClass('sidebar-open').removeClass('sidebar-collapse');
  }
  else{
    $('#side').addClass('sidebar-collapse').removeClass('sidebar-open');
  }
});
</script>
</body>
</html>
<?php /**PATH /home/npfexcha/public_html/demo/resources/views/layouts/app.blade.php ENDPATH**/ ?>