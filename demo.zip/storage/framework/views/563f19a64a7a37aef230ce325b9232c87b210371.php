<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <section class="content">
<div class="container">
    
    <div class="row  pt-5">
        <div class="col-md-3">
            <div class="card">
                <div class="card-header">Total Users</div>
                <div class="card-body">
                    <h5><?php echo e($users); ?></h5>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card">
                <div class="card-header">Active Users</div>
                <div class="card-body">
                    <h5><?php echo e($active_users); ?></h5>
                </div>
            </div>
        </div>





        

       
        <div class="col-md-3">
            <div class="card">
                <div class="card-header">Total Traders</div>
                <div class="card-body">
                    <h5><?php echo e($total_traders); ?></h5>
                </div>
            </div>
        </div>
       <div class="col-md-3">
            <div class="card">
                <div class="card-header">Total Coins</div>
                <div class="card-body">
                    <h5><?php echo e($total_coins); ?></h5>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card">
                <div class="card-header">Total Assets</div>
                <div class="card-body">
                    <h5><?php echo e($total_assets); ?></h5>
                </div>
            </div>
        </div>
       <div class="col-md-3">
            <div class="card">
                <div class="card-header">Total Post</div>
                <div class="card-body">
                    <h5><?php echo e($total_posts); ?></h5>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card">
                <div class="card-header">Today Complete Deposit</div>
                <div class="card-body">
                    <h5>$<?php echo e($today_completed_payments); ?></h5>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card">
                <div class="card-header"> Pending Deposits</div>
                <div class="card-body">
                    <h5><?php echo e($total_pending_payments); ?></h5>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card">
                <div class="card-header"> Complete Deposits</div>
                <div class="card-body">
                    <h5><?php echo e($total_completed_payments); ?></h5>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card">
                <div class="card-header"> Reject Deposits</div>
                <div class="card-body">
                    <h5><?php echo e($total_rejected_payments); ?></h5>
                </div>
            </div>
        </div>



        <div class="col-md-3">
            <div class="card">
                <div class="card-header">Total Pending Deposits</div>
                <div class="card-body">
                    <h5>$<?php echo e($total_pending_payments); ?></h5>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card">
                <div class="card-header">Total Complete Payments</div>
                <div class="card-body">
                    <h5>$<?php echo e($completed_payments); ?></h5>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card">
                <div class="card-header">Total Reject Payments</div>
                <div class="card-body">
                    <h5>$<?php echo e($rejected_payments); ?></h5>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card">
                <div class="card-header">Pending P2P Deposits</div>
                <div class="card-body">
                    <h5>$<?php echo e($pending_deposit); ?></h5>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card">
                <div class="card-header">Complete P2P Deposits</div>
                <div class="card-body">
                    <h5>$<?php echo e($completed_deposit); ?></h5>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card">
                <div class="card-header">Reject P2P Deposits</div>
                <div class="card-body">
                    <h5>$<?php echo e($rejected_deposit); ?></h5>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card">
                <div class="card-header">Pending Withdraw</div>
                <div class="card-body">
                    <h5>$<?php echo e($pending_withdraw); ?></h5>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card">
                <div class="card-header">Complete Withdraw</div>
                <div class="card-body">
                    <h5>$<?php echo e($completed_withdraw); ?></h5>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card">
                <div class="card-header">Reject Withdraw</div>
                <div class="card-body">
                    <h5>$<?php echo e($rejected_withdraw); ?></h5>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card">
                <div class="card-header">Total Spot Open Orders</div>
                <div class="card-body">
                    <h5><?php echo e($total_spot_open_orders); ?></h5>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card">
                <div class="card-header">Total Spot Close Orders</div>
                <div class="card-body">
                    <h5><?php echo e($total_spot_close_orders); ?></h5>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card">
                <div class="card-header">Total Future Open Orders</div>
                <div class="card-body">
                    <h5><?php echo e($total_future_open_orders); ?></h5>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card">
                <div class="card-header">Total Future close Orders</div>
                <div class="card-body">
                    <h5><?php echo e($total_future_close_orders); ?></h5>
                </div>
            </div>
        </div>


     


    </div>
</div>
    </section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/npfexcha/public_html/demo/resources/views/admin/home.blade.php ENDPATH**/ ?>