<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <section class="content">
        <div class="container-fluid">
            <?php if(session('success')): ?>
                <div class="alert alert-success"><?php echo e(session('success')); ?></div>
            <?php endif; ?>
            <?php if(session('error')): ?>
                <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
            <?php endif; ?>
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title ">All Users</h3>
                    <div class="card-tools d-block d-md-flex mt-1">
                        <form class="form-inline ml-3" action="" method="get" id="invest_type">
                            <div class="input-group input-group-sm">
                             <select name="type" id="" class="form-control form-select" required>
                              <option value="" disabled selected>Select Type</option>
                              <option value="name" <?php echo e(Request()->type == 'name' ? 'selected': ''); ?>>Name</option>
                              <option value="email" <?php echo e(Request()->type == 'email' ? 'selected': ''); ?>>Email</option>
                              <option value="uid" <?php echo e(Request()->type == 'uid' ? 'selected':''); ?>>User Id</option>
                              <option value="spid" <?php echo e(Request()->type == 'spid' ? 'selected':''); ?>>Sponser Id</option>
                              </select>
                            </div>


                            <div class="input-group input-group-sm mt-3 mt-sm-0   ml-lg-3    ">
                                <input class="form-control form-control-navbar" type="search" placeholder="Search"  name="search" value="<?php echo e(Request()->search); ?>" required>
                                <div class="input-group-append">
                                    <button class="btn btn-success" type="submit">
                                    <i class="fas fa-search"></i>
                                    </button>
                                    <a class="btn btn-danger ml-3" href="<?php echo e(route('admin.users')); ?>">Reset </a>

                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <!-- /.card-header -->
                <div class="card-body p-0">
                  <div class="table-responsive">
                  <table class="table ">
                    <thead>
                      <tr>
                        <th >#</th>
                        <th>Name</th>
                        <th>Phone</th>
                        <th>Email</th>
                        <th>Password</th>
                        <th>UID</th>
                        <th>Sponser</th>
                        
                        <th style="min-width:120px;">Date</th>
                        <th style="min-width:330px;">Action</th>
                      </tr>
                    </thead>
                    <tbody>
                        <?php if(!empty($users)): ?>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($users->firstItem()+$key); ?></td>
                            <td><?php echo e($user->name); ?></td>
                            <td><?php echo e($user->phone); ?></td>
                            <td><?php echo e($user->email); ?></td>
                            <td><?php echo e($user->showPass); ?></td>
                            <td><?php echo e($user->uid); ?></td>
                            <td><?php echo e($user->spid); ?></td>
                            
                            <td><?php echo e($user->created_at); ?></td>
                            <td class="d-flex" >
                                <a href="<?php echo e(route('admin.editUser',$user->id)); ?>" class="btn btn-warning btn-sm mr-2">Edit</a>
                                
                                <a href="<?php echo e(route('admin.sendEpin',$user->id)); ?>" class="btn btn-secondary btn-sm mr-2">Send USDT</a>
                                <button type="button" class="btn btn-info btn-sm mr-2" onclick="Login(<?php echo e($user->id); ?>)">Login</button>
                                
                                
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>
                  </table>
                  <?php echo e($users->links()); ?>

                  </div>
                </div>
              </div>
        </div>
    </section>
</div>
<script>
  function Login(id){
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>"
        }
    });

    $.ajax({
      url:"<?php echo e(route('admin.user_login')); ?>",
      method:"POST",
      data:{
        id:id
      },
      success:function(data){
          if(data.token){
            localStorage.removeItem('token');
            localStorage.setItem('token',data.token);
            // window.location.href = "<?php echo e(route('user.home')); ?>";
            window.open("<?php echo e(route('user.home')); ?>",'_blank');
          }
      }
    });
  }
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/npfexcha/public_html/demo/resources/views/admin/users.blade.php ENDPATH**/ ?>