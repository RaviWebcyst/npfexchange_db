<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class timer extends Model
{
    protected $guarded = [];
}
