<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class payment_log extends Model
{
    protected $table = "payments_logs";
    protected $guarded = [];
}
