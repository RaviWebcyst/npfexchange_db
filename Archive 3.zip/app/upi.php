<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class upi extends Model
{
    protected $guarded = [];
}
