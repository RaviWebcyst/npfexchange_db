<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class open_order extends Model
{
    protected $guarded = [];
}
