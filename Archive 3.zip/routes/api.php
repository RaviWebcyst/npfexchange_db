<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

Route::post("myOrders",'usersController@myOrders');
Route::post("allOrders",'usersController@allOrders');
Route::post("getResult",'usersController@getResult');
Route::post("transactions",'usersController@transactions');
Route::post("getUserDetails",'usersController@userDetails');
Route::post("userlogin",'usersController@userlogin');
Route::post("getSponser",'usersController@getSponser');
Route::post("payment",'usersController@payment');
Route::post("getPayments",'usersController@getPayments');
Route::post("submitBet",'usersController@submitBet');
Route::post("updateProfile",'usersController@updateProfile');
Route::post("prevGames",'usersController@prevGames');
Route::post("lastGame",'usersController@lastGame');
Route::post("allGames",'usersController@allGames');
Route::get("getGameId",'usersController@getGameId');
Route::post("userLogout",'usersController@userLogout');
Route::post("cash_payments",'usersController@cash_payments');
Route::post("direct_list",'usersController@direct_list');
Route::post("team_list",'usersController@team_list');
Route::post("withdraw",'usersController@withdraw');
Route::post("withdraw_live",'usersController@withdraw_live');
Route::post("withdraws",'usersController@withdraw_details');

Route::post("upi",'usersController@getUpi');
Route::post("getTime",'usersController@getTime');

Route::post("post_swap",'usersController@swap');


Route::get("test",'BinanceController@test');

Route::post("getBalance",'BinanceController@getBalance');
Route::post("usdtBalance",'BinanceController@usdtBalance');
Route::post("getPrice",'BinanceController@getPrice');



Route::post("buyCoin",'BinanceController@buyCoin');
Route::post("sellCoin",'BinanceController@sellCoin');

Route::post("manualBuy",'BinanceController@manualBuy');
Route::post("manualSell",'BinanceController@manualSell');
Route::post("closeOrder",'BinanceController@closeOrder');


Route::post("cancelOrder",'BinanceController@cancelOrder');




Route::post("openBuyOrder",'BinanceController@openBuyOrder');
Route::post("openSellOrder",'BinanceController@openSellOrder');



Route::post("tradeHistory",'BinanceController@tradeHistory');
Route::post("user_register",'usersController@user_register');
Route::post("thank_you",'usersController@thankyou');
// Route::post("coinBalance",'usersController@coinBalance');
Route::post("deposit",'BinanceController@deposit');
Route::post("invest",'usersController@invest');
Route::post("post_deposit",'usersController@post_deposit');
Route::post("invest_history",'usersController@invest_history');
Route::post("direct_referral",'usersController@direct_referral');
Route::post("level_bonus",'usersController@level_bonus');

Route::post("packages",'usersController@packages');
Route::post("get_address",'usersController@get_address');


Route::post("coinBalance",'BinanceController@assetBalance');




Route::post("success_url",'BinanceController@success_url');
Route::post("getAssets",'BinanceController@getAssets');
Route::post("getCoins",'BinanceController@getCoins');
Route::post("recieveCoin",'BinanceController@recieveCoin');
Route::get("posts",'usersController@getPosts');
Route::post("deposit_history",'usersController@deposit_history');
Route::post("check_token",'usersController@check_token');
Route::post("getGasFee",'BinanceController@getGasFee');
Route::post("sendToken",'BinanceController@sendToken');
Route::post("transferToken",'BinanceController@transferToken');
Route::post("openOrders",'BinanceController@openOrders');
Route::post("closeOrders",'BinanceController@closeOrders');
Route::post("crypto_history",'BinanceController@crypto_history');
Route::get("coin_details",'BinanceController@coin_details');
Route::get("coin_balance",'BinanceController@coin_balance');
Route::get("total_balance",'BinanceController@total_balance');
Route::get("asset_price",'BinanceController@asset_price');
Route::post("getAssetPrice",'BinanceController@getAssetPrice');
Route::post("transfer_usdt",'BinanceController@transferCoin');



//future api's
Route::post("getFutureSymbols",'FutureController@getSymbols');
Route::get("future_coin_details",'FutureController@coin_details');
Route::post("getFuturePrice",'FutureController@getAssetPrice');
Route::get("getLeverage",'FutureController@getLeverage');
Route::post("setLeverage",'FutureController@setLeverage');
Route::post("setMargin",'FutureController@setMargin');

Route::post("manualFutureBuy",'FutureController@manualBuy');
Route::post("manualFutureSell",'FutureController@manualSell');
Route::get("openPositions",'FutureController@openPositions');
Route::get("positionHistory",'FutureController@positionHistory');
Route::post("closePosition",'FutureController@closePosition');
Route::post("coinFutureBalance",'FutureController@coinBalance');
Route::get("future_total_balance",'FutureController@total_balance');
Route::post("limitBuyOrder",'FutureController@openBuyOrder');
Route::post("limitSellOrder",'FutureController@openSellOrder');
Route::post("openFutureOrders",'FutureController@openOrders');
Route::post("futureOrderHistory",'FutureController@orderHistory');
Route::post("updatePl",'FutureController@updatePl');
Route::post("cancelFutureOrder",'FutureController@cancelOrder');






//future api's end




Route::post("getSymbols",'usersController@getSymbols');
Route::post("transfer_history",'usersController@transfer_history');

Route::post("forgetPassword",'usersController@forgetPassword');
Route::post("verfiyOtp",'usersController@verfiyOtp');

Route::post("npfPrices",'usersController@npf_prices');

Route::get("usdt_price",'usersController@usdt_price');

Route::get("getLiveDeposits",'usersController@getLiveDeposits');
Route::post("set_transactions",'usersController@set_transactions');


Route::get("getEthLiveDeposits",'usersController@getEthLiveDeposits');
// Route::post("set_eth_transactions",'usersController@set_eth_transactions');
Route::post("setTronTransaction",'usersController@setTronTransaction');







// Route::get("curl",'usersController@curl');
